"""Main wrapper for D4FT"""

import os

from absl import app, flags, logging
from jax.config import config

import d4ft
import d4ft.geometries
from d4ft.functions import wave2density
from d4ft.energy import energy_gs, integrand_kinetic, integrand_external, integrand_hartree, integrand_x_lsda
from d4ft.energy import energy_lsda, energy_gga, integrand_x_gga
from d4ft.hamiltonian import *

import numpy as np
import jax.numpy as jnp
import jax
import jax.random as jrdm
from tqdm import tqdm
import matplotlib.pyplot as plt
import haiku as hk
import optax

class SpectralConv1d(hk.Module):
    def __init__(self, in_channels, out_channels, modes1):
        super(SpectralConv1d, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.modes1 = modes1 # Number of Fourier modes to multiply, at most floor(N/2) + 1
        self.scale = (1 / (in_channels))

    def __call__(self, x):
        batchsize = jnp.shape(x)[0]
        x_ft = jnp.fft.rfft(x)
        w1_init = hk.initializers.RandomUniform(maxval=self.scale) #ComplexRandomUniform(maxval=self.scale)
        w2_init = hk.initializers.Constant(constant=0)
        weights1 = hk.get_parameter("weights1", shape=[self.in_channels, self.out_channels, self.modes1], dtype=x.dtype, init=w1_init)
        weights2 = hk.get_parameter("weights2", shape=[self.in_channels, self.out_channels, self.modes1], dtype=x.dtype, init=w2_init)
        out_ft = jnp.zeros((batchsize, self.out_channels, jnp.shape(x)[-1] // 2 + 1), dtype=x_ft.dtype)
        out_ft = out_ft.at[:, :, :self.modes1].set(jnp.einsum("bix,iox->box", x_ft[:, :, :self.modes1], weights1))
        out_ft = out_ft.at[:, :, :self.modes1].add(jnp.einsum("bix,iox->box", x_ft[:, :, :self.modes1], weights2 * 1.j))
        x = jnp.fft.irfft(out_ft, n=jnp.shape(x)[-1])
        return x

class FNO1d(hk.Module):
    def __init__(self, modes, width, layers):
        super(FNO1d, self).__init__()
        self.modes1 = modes
        self.width = width
        self.padding = 2 # pad the domain if input is non-periodic
        self.fc0 = hk.Linear(self.width) # input channel is 2: (a(x), x)
        self.layers = layers

        self.conv = [SpectralConv1d(self.width, self.width, self.modes1) for _ in range(layers)]
        self.w = [hk.Conv1D(self.width, 1, data_format='NCW') for _ in range(layers)]

        """self.conv0 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv1 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv2 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv3 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv4 = SpectralConv1d(self.width, self.width, self.modes1)
        self.w0 = hk.Conv1D(self.width, 1, data_format='NCW')
        self.w1 = hk.Conv1D(self.width, 1, data_format='NCW')
        self.w2 = hk.Conv1D(self.width, 1, data_format='NCW')
        self.w3 = hk.Conv1D(self.width, 1, data_format='NCW')
        self.w4 = hk.Conv1D(self.width, 1, data_format='NCW')"""

        self.fc1 = hk.Linear(128)
        self.fc2 = hk.Linear(1)

    def __call__(self, x, n, nabla_n):
        x = jnp.concatenate([x, n, nabla_n], axis=-1)
        x = jnp.expand_dims(x, 0)
        x = self.fc0(x)
        x = jnp.transpose(x, (0, 2, 1))

        for i in range(self.layers):
          x1 = self.conv[i](x)
          x2 = self.w[i](x)
          x = x1 + x2
          if i != self.layers - 1:
            x = jax.nn.gelu(x)

        """x1 = self.conv0(x)
        x2 = self.w0(x)
        x = x1 + x2
        x = jax.nn.gelu(x)

        x1 = self.conv1(x)
        x2 = self.w1(x)
        x = x1 + x2
        x = jax.nn.gelu(x)

        x1 = self.conv2(x)
        x2 = self.w2(x)
        x = x1 + x2
        x = jax.nn.gelu(x)

        x1 = self.conv3(x)
        x2 = self.w3(x)
        x = x1 + x2
        x = jax.nn.gelu(x)

        x1 = self.conv4(x)
        x2 = self.w4(x)
        x = x1 + x2"""

        # x = x[..., :-self.padding] # pad the domain if input is non-periodic
        x = jnp.transpose(x, (0, 2, 1))
        x = self.fc1(x)
        x = jax.nn.gelu(x)
        x = self.fc2(x)
        x = jnp.reshape(x, (x.shape[1], x.shape[2]))
        return x

FLAGS = flags.FLAGS

flags.DEFINE_integer("batch_size", 1100, "batch size")
flags.DEFINE_integer("epoch", 10001, "epoch")
flags.DEFINE_float("converge_threshold", 1e-8, "")
flags.DEFINE_float("lr", 1e-3, "learning rate for sgd")
flags.DEFINE_float("momentum", 5e-2, "momentum for scf")
flags.DEFINE_bool("pre_cal", False, "whether to pre-calculate the integrals")
flags.DEFINE_integer("seed", 137, "random seed")
flags.DEFINE_integer("spin", 0, "total spin")
flags.DEFINE_string("geometry", "h2", "")
flags.DEFINE_string("opt", "adam", "optimizer")
flags.DEFINE_string("basis_set", "sto-3g", "which basis set to use")
flags.DEFINE_string("device", "0", "cuda visible device")
flags.DEFINE_bool("lr_decay", True, "whether to use a piecewise linear")
flags.DEFINE_string("xc", "lda", "exchange functional")
flags.DEFINE_integer("quad_level", 0, "number of the quadrature points")
flags.DEFINE_bool("use_f64", False, "whether to use float64")
flags.DEFINE_bool("debug_nans", False, "whether to enable nan debugging in jax")
flags.DEFINE_enum("algo", "sgd", ["sgd", "scf"], "which algorithm to use")

flags.DEFINE_float("lam_f", 0.0, "")
flags.DEFINE_integer("size", 1192, "")
flags.DEFINE_integer("N_data", 1100, "")
flags.DEFINE_string("energy", "lda", "")

flags.DEFINE_integer("FNO_width", 64, "")
flags.DEFINE_integer("FNO_modes", 16, "")
flags.DEFINE_integer("FNO_layers", 5, "")

@jax.jit
def batch_sampler(n, nabla_n, nabla2_n, y, dy, e):
  batch_size = FLAGS.batch_size
  npoint = n.shape[0]
  batchsize = min(npoint, batch_size)
  idx = np.arange(npoint)
  idx = np.random.permutation(idx)
  n, nabla_n, nabla2_n, y, dy, e = n[idx], nabla_n[idx], nabla2_n[idx], y[idx], dy[idx], e[idx]

  batch_size = min(npoint, batch_size)
  nbatch = int(npoint / batch_size)

  _n = jnp.split(n[:nbatch * batch_size], nbatch)
  _nabla_n = jnp.split(nabla_n[:nbatch * batch_size], nbatch)
  _nabla2_n = jnp.split(nabla2_n[:nbatch * batch_size], nbatch)
  _y = jnp.split(y[:nbatch * batch_size], nbatch)
  _dy = jnp.split(dy[:nbatch * batch_size], nbatch)
  _e = jnp.split(e[:nbatch * batch_size], nbatch)

  return list(zip(_n, _nabla_n, _nabla2_n, _y, _dy, _e))

def main(_):
  os.environ["CUDA_VISIBLE_DEVICES"] = FLAGS.device

  logging.set_verbosity(logging.INFO)

  config.update("jax_enable_x64", FLAGS.use_f64)
  config.update("jax_debug_nans", FLAGS.debug_nans)

  geometry = getattr(d4ft.geometries, FLAGS.geometry + "_geometry")
  mol = d4ft.Molecule(
    geometry,
    spin=FLAGS.spin,
    level=FLAGS.quad_level,
    basis=FLAGS.basis_set,
    algo=FLAGS.algo,
    xc=FLAGS.xc
  )

  n, nabla_n, nabla2_n, y, e, h = [], [], [] ,[], [], []

  x, w = np.asarray(mol.grids), np.asarray(mol.weights)
  N_grid = np.shape(x)[0]
  idx = np.random.choice(N_grid, size=FLAGS.size, replace=False)
  x, w = x[idx], w[idx]
  w = w.reshape(1, -1, 1) # / FLAGS.size * len(mol.grids)

  @jax.jit
  def data_generation(params):
    def mo(r):
      return mol.mo(params, r) * mol.nocc
    rho = wave2density(mo)
    nabla_rho = jax.vmap(jax.grad(rho), in_axes=(0))
    nabla2_rho = jax.vmap(jax.hessian(rho), in_axes=(0))
    rho = jax.vmap(rho, in_axes=(0))
    
    n_, nabla_n_, nabla2_n_ = rho(x), nabla_rho(x), nabla2_rho(x).reshape(-1, 9)

    if FLAGS.energy == "lda":
      e_xc = energy_lsda(mo, (mol.grids, mol.weights))
      y_xc = jax.vmap(integrand_x_lsda(mo))(x)
      h_xc = hamil_lda(mo, x)
    elif FLAGS.energy == "gga":
      y_xc = integrand_x_gga(n_, nabla_n_) # integrand_x_gga(rho, nabla_rho)(x)
      e_xc = jnp.dot(y_xc, mol.weights) # energy_gga(rho, nabla_rho, (mol.grids, mol.weights))
      h_xc = hamil_gga(x, n_, nabla_n_, nabla2_n_)
    return n_, nabla_n_, nabla2_n_, [y_xc], [e_xc], [h_xc]

    """e_total, e = energy_gs(mo, mol.nuclei, (mol.grids, mol.weights))
    e_kin, e_ext, e_xc, e_hartree, e_nuc = e
    
    y_kin = jax.vmap(integrand_kinetic(mo))(x)
    y_ext = jax.vmap(integrand_external(mo, mol.nuclei))(x)
    y_xc = jax.vmap(integrand_x_lsda(mo))(x)
    y_hartree = hamil_hartree(mo, (mol.grids, mol.weights), x) * rho(x) / 2# jax.vmap(integrand_hartree(mo))(x)

    h_ext = hamil_external(mol.nuclei, x)
    h_xc = hamil_lda(mo, x)
    h_hartree = hamil_hartree(mo, (mol.grids, mol.weights), x) 

    return n_, nabla_n_, nabla2_n_, [y_kin, y_ext, y_xc, y_hartree], [e_kin, e_ext, e_xc, e_hartree], [h_ext, h_xc, h_hartree]"""

  for seed in tqdm(range(FLAGS.N_data)):
    params = mol._init_param(seed)
    n_, nabla_n_, nabla2_n_, y_, e_, h_ = data_generation(params)
    n.append(n_)
    nabla_n.append(nabla_n_)
    nabla2_n.append(nabla2_n_)
    y.append(y_)
    e.append(e_)
    h.append(h_)

  n, nabla_n, nabla2_n, y, dy, e = np.expand_dims(np.asarray(n), -1), np.asarray(nabla_n), np.asarray(nabla2_n), np.asarray(y).transpose(0, 2, 1), np.asarray(h).transpose(0, 2, 1), np.asarray(e)
  print(n.shape, nabla_n.shape, nabla2_n.shape, y.shape, dy.shape, e.shape)
  print(y.max(), y.min(), y.mean(), "|", dy.max(), dy.min(), dy.mean(), "|", e.max(), e.min(), e.mean())
  """if FLAGS.energy == "kin":
    y, dy, e = y[:, :, 0:1], dy[:, :, 0:1], e[:, 0:1]
  elif FLAGS.energy == "ext":
    y, dy, e = y[:, :, 1:2] / 1e3, dy[:, :, 0:1], e[:, 1:2] / 1e3
  elif FLAGS.energy == "lda":
    y, dy, e = y[:, :, 2:3], dy[:, :, 1:2], e[:, 2:3]
  elif FLAGS.energy == "hartree":
    y, dy, e = y[:, :, 3:4], dy[:, :, 2:3], e[:, 3:4]"""

  length = n.shape[0]
  train_n, test_n = n[:int(0.9 * length)], n[int(0.9 * length):]
  train_nabla_n, test_nabla_n = nabla_n[:int(0.9 * length)], nabla_n[int(0.9 * length):]
  train_nabla2_n, test_nabla2_n = nabla2_n[:int(0.9 * length)], nabla2_n[int(0.9 * length):]
  train_m, test_m = y[:int(0.9 * length)], y[int(0.9 * length):]
  train_dy, test_dy = dy[:int(0.9 * length)], dy[int(0.9 * length):]
  train_y, test_y = e[:int(0.9 * length)], e[int(0.9 * length):]

  ### Define model
  @hk.transform
  def network(x, n, nabla_n):
    temp = FNO1d(FLAGS.FNO_modes, FLAGS.FNO_width, FLAGS.FNO_layers) 
    return temp(x, n, nabla_n)
  net = hk.without_apply_rng(network)
  grids = np.expand_dims(x, 0)
  x = np.tile(grids, (np.shape(train_n)[0], 1, 1))
  key = jax.random.PRNGKey(FLAGS.seed)
  params = net.init(key, x[0], train_n[0], train_nabla_n[0])
  net_pred_fn = jax.vmap(net.apply, (None, 0, 0, 0))

  def vgrad(f, x):
    y, vjp_fn = jax.vjp(f, x)
    return vjp_fn(jnp.ones(y.shape))[0]

  def fd_pred_fn(params, x, n, nabla_n, nabla2_n):
    y_n = vgrad(lambda n: net.apply(params, x, n, nabla_n), n)
    # y_n = jax.jacrev(net.apply, argnums=2)(params, x, n, nabla_n)
    temp1 = lambda x: vgrad(lambda nabla_n: net.apply(params, x, n, nabla_n), nabla_n)
    temp1 = vgrad(temp1, x)
    temp1 = jnp.sum(temp1, axis=-1, keepdims=1)
    temp2 = lambda nabla_n: vgrad(lambda n: net.apply(params, x, n, nabla_n), n)
    temp2 = vgrad(temp2, nabla_n)
    temp2 = jnp.sum(temp2 * nabla_n, axis=-1, keepdims=1)
    nabla2_n = jnp.reshape(nabla2_n, (-1, 3, 3))
    temp3 = lambda nabla_n_: jnp.squeeze(nabla2_n @ vgrad(lambda nabla_n: net.apply(params, x, n, nabla_n), nabla_n_)[:, :, None])
    temp3 = vgrad(temp3, nabla_n)
    temp3 = jnp.sum(temp3, axis=-1, keepdims=1)
    # print(jnp.shape(y_n), jnp.shape(temp1), jnp.shape(temp2), jnp.shape(temp3))
    #temp1 = jax.jacrev(jax.jacrev(net.apply, argnums=3), argnums=1)(params, x, n, nabla_n)
    #temp2 = jax.jacrev(jax.jacrev(net.apply, argnums=3), argnums=2)(params, x, n, nabla_n)
    #temp3 = jax.jacrev(jax.jacrev(net.apply, argnums=3), argnums=3)(params, x, n, nabla_n)
    return y_n - temp1 - temp2 - temp3
  fd_pred_fn = jax.vmap(fd_pred_fn, (None, 0, 0, 0, 0))
  fd_pred_fn(params, jnp.tile(grids, (jnp.shape(test_n)[0], 1, 1))[:1], test_n[:1], test_nabla_n[:1], test_nabla2_n[:1])

  lr = optax.exponential_decay(init_value=FLAGS.lr, transition_steps=5000, decay_rate=0.9)
  optimizer = optax.adam(lr)
  opt_state = optimizer.init(params)
  train_dataloader = batch_sampler(train_n, train_nabla_n, train_nabla2_n, train_m, train_dy, train_y)
  test_dataloader = batch_sampler(test_n, test_nabla_n, test_nabla2_n, test_m, test_dy, test_y)

  @jax.jit
  def get_loss(params, x, n, nabla_n, nabla2_n, m, dy):
    y_pred = net_pred_fn(params, x, n, nabla_n)
    #ret = jnp.mean((y_pred - m)**2)
    ret = jnp.sum(((1 * w + 1) * (y_pred - m))**2, axis=1)
    ret = jnp.mean(ret)
    if FLAGS.lam_f > 0:
      f_pred = fd_pred_fn(params, x, n, nabla_n, nabla2_n)
      ret += FLAGS.lam_f * jnp.mean(jnp.sum(((1 * w + 1) * (f_pred - dy))**2, axis=1))
    return ret

  @jax.jit
  def test_loss(params, n, nabla_n, nabla2_n, m, y, dy):
    x = jnp.tile(grids, (jnp.shape(n)[0], 1, 1)) # get_grid(jnp.shape(n))
    y_pred = net_pred_fn(params, x, n, nabla_n)
    i_pred = jnp.sum(w * y_pred, axis=1) / FLAGS.size * len(mol.grids)
    i = jnp.sum(w * m, axis=1) / FLAGS.size * len(mol.grids)
    f_pred = fd_pred_fn(params, x, n, nabla_n, nabla2_n)
    return y_pred, i_pred, f_pred, i

  @jax.jit
  def step(params, opt_state, n, nabla_n, nabla2_n, m, dy):
    x = jnp.tile(grids, (jnp.shape(n)[0], 1, 1))
    current_loss, gradients = jax.value_and_grad(get_loss)(params, x, n, nabla_n, nabla2_n, m, dy)
    updates, opt_state = optimizer.update(gradients, opt_state)
    params = optax.apply_updates(params, updates)
    return current_loss, params, opt_state
    
  for epoch in tqdm(range(FLAGS.epoch)):
    for train_n, train_nabla_n, train_nabla2_n, train_m, train_dy, train_y in train_dataloader:
      current_loss, params, opt_state = step(params, opt_state, train_n, train_nabla_n, train_nabla2_n, train_m, train_dy)
    if epoch%1000==0:
      pred, pred_i, pred_f, pred_i_2 = [], [], [], []
      for test_n, test_nabla_n, test_nabla2_n, test_m, test_dy, test_y in test_dataloader:
        ret1, ret2, ret3, ret4 = test_loss(params, test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy)
        pred.append(ret1); pred_i.append(ret2); pred_f.append(ret3); pred_i_2.append(ret4)
      pred, pred_i, pred_f, i = jnp.concatenate(pred), jnp.concatenate(pred_i), jnp.concatenate(pred_f), jnp.concatenate(pred_i_2)
      err_func = jnp.linalg.norm(jnp.reshape(pred - test_m, (-1,))) / jnp.linalg.norm(jnp.reshape(test_m, (-1,)))
      err_intor = jnp.linalg.norm(jnp.reshape(pred_i - test_y, (-1,))) / jnp.linalg.norm(jnp.reshape(test_y, (-1,)))
      err_intor_2 = jnp.linalg.norm(jnp.reshape(pred_i - i, (-1,))) / jnp.linalg.norm(jnp.reshape(i, (-1,)))
      err_FD = jnp.linalg.norm(jnp.reshape(pred_f - test_dy, (-1,))) / jnp.linalg.norm(jnp.reshape(test_dy, (-1,)))
      print(pred_f.shape)
      print('epoch %d, loss: %E, err_func: %E, err_intor: %E, error_intor_2: %E, err_FD: %E'%(epoch, current_loss, err_func, err_intor, err_intor_2, err_FD))

if __name__ == '__main__':
  app.run(main)
