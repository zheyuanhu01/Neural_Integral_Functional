import haiku as hk
import jax
import numpy as np
import jax.numpy as jnp
from typing import Any, Sequence, Union
import optax
import matplotlib.pyplot as plt
from tqdm import tqdm
from torch.utils.data import DataLoader, TensorDataset
import argparse
import sympy as sy
from jax.flatten_util import ravel_pytree

class MLP(hk.Module):
    def __init__(self, layers):
        super().__init__()
        self.layers = layers

    def __call__(self, x, n, nabla_n):
        x = jnp.hstack([x, n, nabla_n])
        for dim in self.layers[:-1]:
            x = hk.Linear(dim)(x)
            x = jax.nn.gelu(x)
        x = hk.Linear(self.layers[-1])(x)
        return x[0]

def Phi(grid, N=10):
    x = sy.symbols('x')
    ret = [1, 2 * x]
    ret_diff = []
    ret_hess = []
    for i in range(N - 2):
        ret.append(2 * x * ret[-1] - ret[-1].diff(x))
    for i in range(N):
        ret[i] = ret[i] * sy.exp(-x*x/2) / (np.power(np.pi, 0.25) * np.power(2, i/2) * np.sqrt(np.math.factorial(i)))
        ret_diff.append(sy.lambdify([x], ret[i].diff(x), 'numpy'))
        ret_hess.append(sy.lambdify([x], ret[i].diff(x).diff(x), 'numpy'))
        ret[i] = sy.lambdify([x], ret[i], 'numpy')
    """x = sy.symbols('x')
    ret = [1 + 0 * x, 2 * x]
    ret_diff = []
    ret_hess = []
    for i in range(N - 2):
        ret.append(2 * x * ret[-1] - ret[-1].diff(x))
    for i in range(N):
        ret[i] = ret[i] / (np.power(np.pi, 0.25) * np.power(2, i/2) * np.sqrt(np.math.factorial(i)))
        ret_diff.append(sy.lambdify([x], ret[i].diff(x) - x * ret[i], 'numpy'))
        ret_hess.append(sy.lambdify([x], ret[i].diff(x).diff(x) - 2 * x * ret[i].diff(x) - (1 + x**2) * ret[i], 'numpy'))
        ret[i] = sy.lambdify([x], ret[i], 'numpy')"""
    phi, nabla_phi, nabla2_phi = [], [], []
    for i in range(1, N):
        phi.append(ret[i](grid))
        nabla_phi.append(ret_diff[i](grid))
        nabla2_phi.append(ret_hess[i](grid))
    phi, nabla_phi, nabla2_phi = np.asarray(phi), np.asarray(nabla_phi), np.asarray(nabla2_phi)
    print(phi.shape, nabla_phi.shape, nabla2_phi.shape)
    Q, _ = jnp.linalg.qr(np.random.randn(args.N_data, N-1, N // 2) / jnp.sqrt(N-1))
    Q = Q.transpose(0, 2, 1)
    psi = Q @ phi.reshape(-1, N-1, args.N_grid)
    n = np.sum(psi**2, 1)
    nabla_psi = Q @ nabla_phi.reshape(-1, N-1, args.N_grid)
    nabla2_psi = Q @ nabla2_phi.reshape(-1, N-1, args.N_grid)
    nabla_n = np.sum(2 * psi * nabla_psi, 1)
    nabla2_n = np.sum(2 * psi * nabla2_psi, 1) + np.sum(2 * nabla_psi**2, 1)
    #n, nabla_n, nabla2_n = n.T, nabla_n.T, nabla2_n.T
    print(n.shape, nabla_n.shape, nabla2_n.shape)
    return n, nabla_n, nabla2_n

def get_grid(batchsize, size_x):
    gridx = jnp.linspace(-10, 10, size_x)
    gridx = jnp.reshape(gridx, (1, size_x, 1))
    gridx = jnp.repeat(gridx, batchsize, axis=0)
    gridx = jnp.reshape(gridx, (batchsize * size_x,))
    #gridx = gridx.reshape(1, size_x, 1).repeat([batchsize, 1, 1])
    return gridx

def TF(n):
    m = n**3
    y = jnp.mean(m, -1) * 20
    dy = 3 * n**2
    return m, y, dy

def ext(x, n):
    #print("shape", jnp.shape(x), jnp.shape(n))
    m = 0.5 * x**2 * n#**3
    y = jnp.mean(m, -1) * 20
    dy = 0.5 * x**2# * 3 * n**2
    return m, y, dy

def Bosonic(x, n, nabla_n, nabla2_n):
    m = nabla_n ** 2 / n
    y = jnp.mean(m, -1) * 20
    dy = (nabla_n / n)**2 - 2 * nabla2_n / n
    return m, y, dy
    """m = nabla_n ** 2
    y = jnp.mean(m, -1) * 20
    dy = - 2 * nabla2_n 
    return m, y, dy"""

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Neural Functional Project')
    parser.add_argument('--N_data', type=int, default=1100)
    parser.add_argument('--N_grid', type=int, default=256)
    parser.add_argument('--batch_size', type=int, default=1000)
    parser.add_argument('--epochs', type=int, default=20001)
    parser.add_argument('--lam_f', type=float, default=0)
    parser.add_argument('--energy', type=str, default="ext")
    parser.add_argument('--seed', type=int, default=0)
    args = parser.parse_args()
    key = jax.random.PRNGKey(args.seed)
    #grid, w = np.polynomial.hermite.hermgauss(args.N_grid)
    grid = np.linspace(-10, 10, args.N_grid)
    n, nabla_n, nabla2_n = Phi(grid)
    """temp1 = (nabla_n[1, 101:141] - nabla_n[1, 100:140]) / 20 * args.N_grid
    print(temp1)
    print(nabla2_n[1, 100:140])"""
    if args.energy == "TF":
        m, y, dy = TF(n)
    elif args.energy == "ext":
        x = get_grid(jnp.shape(n)[0], args.N_grid).reshape(-1, args.N_grid)
        m, y, dy = ext(x, n)
    elif args.energy == "b":
        x = get_grid(jnp.shape(n)[0], args.N_grid).reshape(-1, args.N_grid)
        m, y, dy = Bosonic(x, n, nabla_n, nabla2_n)
    print(n.shape, nabla_n.shape, nabla2_n.shape, m.shape, y.shape, dy.shape)
    B = args.N_data
    train_n, train_nabla_n, train_y, test_n, test_nabla_n, test_y = n[:int(0.9 * B)], nabla_n[:int(0.9 * B)], \
        y[:int(0.9 * B)], n[int(0.9 * B):], nabla_n[int(0.9 * B):], y[int(0.9 * B):]
    train_dy, test_dy = dy[:int(0.9 * B)], dy[int(0.9 * B):]
    train_nabla2_n, test_nabla2_n = nabla2_n[:int(0.9 * B)], nabla2_n[int(0.9 * B):]
    train_m, test_m = m[:int(0.9 * B)], m[int(0.9 * B):]
    @hk.transform
    def network(x, n, nabla_n):
        temp = MLP([64, 64, 64, 1])
        return temp(x, n, nabla_n)
    net = hk.without_apply_rng(network)
    train_n, train_nabla_n, train_nabla2_n, train_m, train_y, train_dy, test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy = \
        train_n.reshape(-1), train_nabla_n.reshape(-1), train_nabla2_n.reshape(-1), train_m.reshape(-1), train_y.reshape(-1), train_dy.reshape(-1), test_n.reshape(-1), test_nabla_n.reshape(-1), test_nabla2_n.reshape(-1), test_m.reshape(-1), test_y.reshape(-1), test_dy.reshape(-1)
        #train_n.reshape(-1, 1), train_nabla_n.reshape(-1, 1), train_nabla2_n.reshape(-1, 1), train_m.reshape(-1, 1), train_y.reshape(-1, 1), train_dy.reshape(-1, 1), test_n.reshape(-1, 1), test_nabla_n.reshape(-1, 1), test_nabla2_n.reshape(-1, 1), test_m.reshape(-1, 1), test_y.reshape(-1, 1), test_dy.reshape(-1, 1)

    x = get_grid(jnp.shape(train_n)[0] // args.N_grid, args.N_grid)
    params = net.init(key, x[0], train_n[0], train_nabla_n[0])
    net_pred_fn = jax.vmap(net.apply, (None, 0, 0, 0))
    def fd_pred_fn(params, x, n, nabla_n, nabla2_n):
        y_n = jax.grad(net.apply, argnums=2)(params, x, n, nabla_n)
        temp1 = jax.grad(jax.grad(net.apply, argnums=3), argnums=1)(params, x, n, nabla_n)
        temp2 = jax.grad(jax.grad(net.apply, argnums=3), argnums=2)(params, x, n, nabla_n)
        temp3 = jax.grad(jax.grad(net.apply, argnums=3), argnums=3)(params, x, n, nabla_n)
        return y_n - temp1 - temp2 * nabla_n - temp3 * nabla2_n
    fd_pred_fn = jax.vmap(fd_pred_fn, (None, 0, 0, 0, 0))
    out = fd_pred_fn(params, get_grid(jnp.shape(test_n)[0] // args.N_grid, args.N_grid), test_n, test_nabla_n, test_nabla2_n)
    print(jnp.shape(out))

    optimizer = optax.adam(1e-3)
    opt_state = optimizer.init(params)

    @jax.jit
    def get_u_loss(params, x, n, nabla_n, nabla2_n, m, dy):
        y_pred = net_pred_fn(params, x, n, nabla_n)
        ret = jnp.mean((y_pred - m)**2)
        return ret
    
    @jax.jit
    def get_f_loss(params, x, n, nabla_n, nabla2_n, m, dy):
        f_pred = fd_pred_fn(params, x, n, nabla_n, nabla2_n)
        ret = jnp.mean((f_pred - dy)**2) #args.lam_f * 
        return ret

    @jax.jit
    def test_loss(params, x, n, nabla_n, nabla2_n, m, y, dy):
        y_pred = net_pred_fn(params, x, n, nabla_n)
        i_pred = jnp.mean(jnp.reshape(y_pred, (-1, args.N_grid)), axis=1)
        f_pred = fd_pred_fn(params, x, n, nabla_n, nabla2_n)
        return y_pred, i_pred, f_pred
        #err_func = jnp.linalg.norm(jnp.reshape(y_pred - m, (-1,))) / jnp.linalg.norm(jnp.reshape(m, (-1,)))
        #err_intor = jnp.linalg.norm(jnp.reshape(i_pred - y, (-1,))) / jnp.linalg.norm(jnp.reshape(y, (-1,)))
        #err_FD = jnp.linalg.norm(jnp.reshape(f_pred - dy, (-1,))) / jnp.linalg.norm(jnp.reshape(dy, (-1,)))
        #return err_func, err_intor, err_FD

    @jax.jit
    def step(params, opt_state, x, n, nabla_n, nabla2_n, m, dy):
        current_loss, gradients = jax.value_and_grad(get_u_loss)(params, x, n, nabla_n, nabla2_n, m, dy)
        if args.lam_f > 0:
            current_loss, gradients_f = jax.value_and_grad(get_f_loss)(params, x, n, nabla_n, nabla2_n, m, dy)
            flat_g_f, tree_func = ravel_pytree(gradients_f)
            flat_g_u, _ = ravel_pytree(gradients)
            flat_g_f = flat_g_f / jnp.linalg.norm(flat_g_f) * jnp.linalg.norm(flat_g_u)
            flat_g = flat_g_u + args.lam_f * flat_g_f
            gradients = tree_func(flat_g)
        updates, opt_state = optimizer.update(gradients, opt_state)
        params = optax.apply_updates(params, updates)
        return current_loss, params, opt_state
    
    for epoch in tqdm(range(args.epochs)):
        x = get_grid(jnp.shape(train_n)[0] // args.N_grid, args.N_grid)
        current_loss, params, opt_state = step(params, opt_state, x, train_n, train_nabla_n, train_nabla2_n, train_m, train_dy)
        if epoch%1000==0:
            x = get_grid(jnp.shape(test_n)[0] // args.N_grid, args.N_grid)
            pred, pred_i, pred_f = test_loss(params, x, test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy)
            err_func = jnp.linalg.norm(jnp.reshape(pred - test_m, (-1,))) / jnp.linalg.norm(jnp.reshape(test_m, (-1,)))
            err_intor = jnp.linalg.norm(jnp.reshape(20 * pred_i - test_y, (-1,))) / jnp.linalg.norm(jnp.reshape(test_y, (-1,)))
            err_FD = jnp.linalg.norm(jnp.reshape(pred_f - test_dy, (-1,))) / jnp.linalg.norm(jnp.reshape(test_dy, (-1,)))
            print('epoch %d, loss: %.3E, err_func: %.3E, err_intor: %.3E, err_FD: %.3E'%(epoch, current_loss, err_func, err_intor, err_FD))
