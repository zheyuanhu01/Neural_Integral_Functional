# Implementation of the helper functions for VWN
# These numbers are taken from the original reference, but divided by
# two to convert from Rydbergs to Hartrees.
# Reference: Vosko, Wilk, and Nusair, Can. J. Phys. 58, 1200 (1980)
# Author: Kunhao Zheng

import jax
import jax.numpy as jnp

A_vwn = [0.0310907, 0.01554535, -1 / (6 * Pi ^ 2)]
b_vwn = [3.72744, 7.06042, 1.13107]
c_vwn = [12.9352, 18.0578, 13.0045]
x0_vwn = [-0.10498, -0.32500, -0.0047584]

A_rpa = [0.0310907, 0.01554535, -1 / (6 * Pi ^ 2)]
b_rpa = [13.0720, 20.1231, 1.06835]
c_rpa = [42.7198, 101.578, 11.4813]
x0_rpa = [-0.409286, -0.743294, -0.228344]


def n2rs(n):
    r_s = (3 / (4 * jnp.pi * n + 1e-40) + 1e-40)**(1 / 3)
    return r_s


def f_zeta(zeta):
    """
  The function f(zeta) in VWN paper, Eq. (2.3).
  f(zeta) = ((1 + zeta)^(4 / 3) + (1 - zeta)^(4 / 3) - 2) / (2 * (2^(1/3) - 1)). 
  """
    return ((1 + zeta)**(4 / 3) + (1 - zeta)**(4 / 3) - 2) / (2 *
                                                              (2**(1 / 3) - 1))


def Q_vwn(b, c):
    """
  The quantity Q in Eq. (4.4) in VWN paper. Q = (4c - b^2)^(1/2).
  """
    # We don't use epsilon because b, c are given as constants from list.
    return jnp.sqrt(4 * c - b * b)


def f1_vwn(b, c):
    """
  The factor before the tan^{-1} in Eq. (4.4) in VWN paper.
  f1 = 2b / Q.
  """
    # We don't use epsilon because b, c are given as constants from list.
    return 2 * b / Q_vwn(b, c)


def fx_vwn(b, c, r_s):
    """
  The quantity X(x) in Eq. (4.4) in VWN paper. X(x) = x^2 + bx + c.
  Under Eq. (4.4), we have x = r_s^(1/2).
  """
    return r_s + b * jnp.sqrt(r_s + 1e-40) + c


def f2_vwn(b, c, x0):
    """
  The factor before the ln in Eq. (4.4) in VWN paper.
  f2 = b * x0 / (x0^2 + b * x0 + c).
  """
    # We don't use epsilon because b, c, x0 are given as constants from list.
    return b * x0 / (x0 * x0 + b * x0 + c)


def f3_vwn(b, c, x0):
    """
  The factor before the 2nd tan^{-1} in Eq. (4.4) in VWN paper.
  f3 = (2 * (b + 2x0))/Q.
  """
    # We don't use epsilon because b, c, x0 are given as constants from list.
    # So Q should not be 0.
    return 2 * (b + 2 * x0) / Q_vwn(b, c)


def fpp_vwn():
    """
  The value of 2nd order derivative of f(x) in Eq. (2.3) in VWN paper.
  The value is 4/(9*(2^(1/3) - 1)).
  """
    return 4 / (9 * (2**(1 / 3) - 1))


def f_aux(A, b, c, x0, r_s):
    """
  The entire function of Eq. (4.4) in VWN paper.
  """
    # We don't use epsilon because b, c, x0 are given as constants from list.
    # So Q should not be 0.
    # The quantity x is replaced by r_s^(1/2).
    # The formula has been rearranged such that the tan^{-1} is grouped together.
    Q = Q_vwn(b, c)
    f1 = f1_vwn(b, c)
    f2 = f2_vwn(b, c, x0)
    f3 = f3_vwn(b, c, x0)
    fx = fx_vwn(b, c, r_s)
    # we should be careful about the value of jnp.log.
    return A * (jnp.log(r_s / fx) +
                (f1 - f2 * f3) * jnp.arctan(Q / (2 * jnp.sqrt(r_s) + b)) +
                -f2 * jnp.log(((jnp.sqrt(r_s) - x0)**2) / fx))


def DMC(r_s):
    """
  The value of DMC is given by 
  Delta epsilon_c(r_s) = epsilon_c^F(r_s) - epsilon_c^P(r_s).
  Where
  epsilon_c^F(r_s): take the 2nd row of parameters into f_aux.
  epsilon_c^P(r_s): take the 1st row of parameters into f_aux.
  """
    return f_aux(A_vwn[1], b_vwn[1], c_vwn[1], x0_vwn[1], r_s) - f_aux(
        A_vwn[0], b_vwn[0], c_vwn[0], x0_vwn[0], r_s)


def DRPA(r_s):
    """
  The value of DRPA is given by
  Delta epsilon_RPA(r_s) = epsilon_RPA^F(r_s) - epsilon_RPA^P(r_s).
  Where
  epsilon_RPA^F(r_s): take the 2nd row of parameters into f_aux.
  epsilon_RPA^P(r_s): take the 1st row of parameters into f_aux.
  """
    return f_aux(A_rpa[1], b_rpa[1], c_rpa[1], x0_rpa[1], r_s) - f_aux(
        A_rpa[0], b_rpa[0], c_rpa[0], x0_rpa[0], r_s)


def f_vwn_rpa(r_s, zeta):
    """
  The value of the correlation functional VWN RPA.
  Eq. (2.4) in VWN paper.
  epsilon_c(r_s) = epsilon_c^P(r_s) + Delta epsilon_c(r_s).
  This function calculates 
  epsilon_RPA(r_s) = epsilon_RPA^P(r_s) + Delta epsilon_RPA(r_s).
  Where Delta epsilon_RPA(r_s) is given by 
  DRPA(r_s) = (epsilon_RPA^F(r_s) - epsilon_RPA^P(r_s)) * f(zeta).
  and f is given by Eq. (2.3) in VWN paper.
  This function groups the two terms epsilon_RPA^P together.
  The epsilon_RPA^P is given by f_aux by taking the 1st columns of parameters.
  The epsilon_RPA^F is given by f_aux by taking the 2nd columns of parameters.
  """
    return f_aux(A_rpa[0], b_rpa[0], c_rpa[0], x0_rpa[0], r_s) * (
        1 - f_zeta(zeta)) + f_aux(A_rpa[1], b_rpa[1], c_rpa[1], x0_rpa[1],
                                  r_s) * f_zeta(zeta)


def f_vwn_1(r_s, zeta):
    """
  The value of the correlation functional VWN 1.
  """
    return f_aux(A_vwn[0], b_vwn[0], c_vwn[0], x0_vwn[0], r_s) * (
        1 - f_zeta(zeta)) + f_aux(A_vwn[1], b_vwn[1], c_vwn[1], x0_vwn[1],
                                  r_s) * f_zeta(zeta)


def f_vwn_2(r_s, zeta):
    """
    f_vwn := (rs, z) ->
  + f_aux(A_vwn[0], b_vwn[0], c_vwn[0], x0_vwn[0], rs)
  + f_aux(A_rpa[2], b_rpa[2], c_rpa[2], x0_rpa[2], rs)*f_zeta(z)*(1 - z^4)/fpp_vwn
  - DRPA(rs, z)*f_zeta(z)*(1 - z^4)
  +  DMC(rs, z)*f_zeta(z):
  """
    return f_aux(A_vwn[0], b_vwn[0], c_vwn[0], x0_vwn[0], r_s) + f_aux(
        A_rpa[2], b_rpa[2], c_rpa[2], x0_rpa[2], r_s) * f_zeta(zeta) * (
            1 - zeta**4) / fpp_vwn() - DRPA(r_s) * f_zeta(zeta) * (
                1 - zeta**4) + DMC(r_s) * f_zeta(zeta)


def f_vwn_3(r_s, zeta):
    """
    f_vwn := (rs, z) ->
  + f_aux(A_vwn[0], b_vwn[0], c_vwn[0], x0_vwn[0], rs)
  + DMC(rs, z)/DRPA(rs, z)*f_aux(A_rpa[2], b_rpa[2], c_rpa[2], x0_rpa[2], rs)*f_zeta(z)*(1 - z^4)/fpp_vwn
  + DMC(rs, z)*f_zeta(z)*z^4:
  """
    return f_aux(
        A_vwn[0], b_vwn[0],
        c_vwn[0], x0_vwn[0], r_s) + DMC(r_s) / DRPA(r_s) * f_aux(
            A_rpa[2], b_rpa[2], c_rpa[2], x0_rpa[2], r_s) * f_zeta(zeta) * (
                1 - zeta**4) / fpp_vwn() + DMC(r_s) * f_zeta(zeta) * zeta**4


def f_vwn_4(r_s, zeta):
    """
    f_vwn := (rs, z) ->
  + f_aux(A_vwn[0], b_vwn[0], c_vwn[0], x0_vwn[0], rs)
  + f_aux(A_rpa[2], b_rpa[2], c_rpa[2], x0_rpa[2], rs)*f_zeta(z)*(1 - z^4)/fpp_vwn
  +  DMC(rs, z)*f_zeta(z)*z^4:
  """
    return f_aux(A_vwn[0], b_vwn[0], c_vwn[0], x0_vwn[0], r_s) + f_aux(
        A_rpa[2], b_rpa[2], c_rpa[2], x0_rpa[2], r_s) * f_zeta(zeta) * (
            1 - zeta**4) / fpp_vwn() + DMC(r_s) * f_zeta(zeta) * zeta**4


def integrand_f_vwn_rpa(rho):
    r_s = n2rs(rho)
    zeta = 0
    return f_vwn_rpa(r_s, zeta) * rho


def integrand_f_vwn_1(rho):
    r_s = n2rs(rho)
    zeta = 0
    return f_vwn_1(r_s, zeta) * rho


def integrand_f_vwn_2(rho):
    r_s = n2rs(rho)
    zeta = 0
    return f_vwn_2(r_s, zeta) * rho


def integrand_f_vwn_3(rho):
    r_s = n2rs(rho)
    zeta = 0
    return f_vwn_3(r_s, zeta) * rho


def integrand_f_vwn_4(rho):
    r_s = n2rs(rho)
    zeta = 0
    return f_vwn_4(r_s, zeta) * rho
