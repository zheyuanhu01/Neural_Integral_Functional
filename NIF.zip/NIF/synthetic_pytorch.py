import torch
from torch import nn
import torch.nn.functional as F
import numpy as np
from typing import Any, Sequence, Union
from tqdm import tqdm
from torch.utils.data import DataLoader, TensorDataset
import argparse

class SpectralConv1d(nn.Module):
    def __init__(self, in_channels, out_channels, modes1):
        super(SpectralConv1d, self).__init__()

        """
        1D Fourier layer. It does FFT, linear transform, and Inverse FFT.    
        """

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.modes1 = modes1  #Number of Fourier modes to multiply, at most floor(N/2) + 1

        self.scale = (1 / (in_channels*out_channels))
        self.weights1 = nn.Parameter(self.scale * torch.rand(in_channels, out_channels, self.modes1, dtype=torch.cfloat))

    # Complex multiplication
    def compl_mul1d(self, input, weights):
        # (batch, in_channel, x ), (in_channel, out_channel, x) -> (batch, out_channel, x)
        return torch.einsum("bix,iox->box", input, weights)

    def forward(self, x):
        batchsize = x.shape[0]
        #Compute Fourier coeffcients up to factor of e^(- something constant)
        x_ft = torch.fft.rfft(x)

        # Multiply relevant Fourier modes
        out_ft = torch.zeros(batchsize, self.out_channels, x.size(-1)//2 + 1,  device=x.device, dtype=torch.cfloat)
        out_ft[:, :, :self.modes1] = self.compl_mul1d(x_ft[:, :, :self.modes1], self.weights1)

        #Return to physical space
        x = torch.fft.irfft(out_ft, n=x.size(-1))
        return x

class FNO1d(nn.Module):
    def __init__(self, modes, width):
        super(FNO1d, self).__init__()

        """
        The overall network. It contains 4 layers of the Fourier layer.
        1. Lift the input to the desire channel dimension by self.fc0 .
        2. 4 layers of the integral operators u' = (W + K)(u).
            W defined by self.w; K defined by self.conv .
        3. Project from the channel space to the output space by self.fc1 and self.fc2 .
        
        input: the solution of the initial condition and location (a(x), x)
        input shape: (batchsize, x=s, c=2)
        output: the solution of a later timestep
        output shape: (batchsize, x=s, c=1)
        """

        self.modes1 = modes
        self.width = width
        self.padding = 2 # pad the domain if input is non-periodic
        self.fc0 = nn.Linear(3, self.width) # input channel is 2: (a(x), x)

        self.conv0 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv1 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv2 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv3 = SpectralConv1d(self.width, self.width, self.modes1)
        self.w0 = nn.Conv1d(self.width, self.width, 1)
        self.w1 = nn.Conv1d(self.width, self.width, 1)
        self.w2 = nn.Conv1d(self.width, self.width, 1)
        self.w3 = nn.Conv1d(self.width, self.width, 1)

        self.fc1 = nn.Linear(self.width, 128)
        self.fc2 = nn.Linear(128, 1)

    def forward(self, x, n, nabla_n):
        #grid = self.get_grid(x.shape, x.device)
        x = torch.cat((x, n, nabla_n), dim=-1)
        x = self.fc0(x)
        x = x.permute(0, 2, 1)
        # x = F.pad(x, [0,self.padding]) # pad the domain if input is non-periodic

        x1 = self.conv0(x)
        x2 = self.w0(x)
        x = x1 + x2
        x = F.gelu(x)

        x1 = self.conv1(x)
        x2 = self.w1(x)
        x = x1 + x2
        x = F.gelu(x)

        x1 = self.conv2(x)
        x2 = self.w2(x)
        x = x1 + x2
        x = F.gelu(x)

        x1 = self.conv3(x)
        x2 = self.w3(x)
        x = x1 + x2

        # x = x[..., :-self.padding] # pad the domain if input is non-periodic
        x = x.permute(0, 2, 1)
        x = self.fc1(x)
        x = F.gelu(x)
        x = self.fc2(x)
        #x = x.squeeze()
        #x = self.fc3(x)
        #x = x.mean(-1)
        return x
    
    def get_grid(self, shape, device):
        batchsize, size_x = shape[0], shape[1]
        gridx = torch.tensor(np.linspace(0, 1, size_x), dtype=torch.float)
        gridx = gridx.reshape(1, size_x, 1).repeat([batchsize, 1, 1])
        return gridx.to(device)
    
    def FD(self, x, n, nabla_n, nabla2_n): # [batch, N_grid, 1]
        out = self.forward(x, n, nabla_n) # [batch, N_grid, 1]
        y_n = torch.autograd.grad(out, n, create_graph=True, grad_outputs=torch.ones_like(out))[0]
        y_nabla_n = torch.autograd.grad(out, nabla_n, create_graph=True, grad_outputs=torch.ones_like(out))[0] # [batch, N_grid, 1]
        temp1 = torch.autograd.grad(y_nabla_n, x, create_graph=True, grad_outputs=torch.ones_like(y_nabla_n))[0] # [batch, N_grid, 1]
        temp2 = torch.autograd.grad(y_nabla_n, n, create_graph=True, grad_outputs=torch.ones_like(y_nabla_n))[0] # [batch, N_grid, 1]
        temp3 = torch.autograd.grad(y_nabla_n, nabla_n, create_graph=True, grad_outputs=torch.ones_like(y_nabla_n))[0] # [batch, N_grid, 1]
        return y_n - temp1 - temp2 * nabla_n - temp3 * nabla2_n

    def polynomial(self, B=10000, N=20, N_grid=1000):
        a = (np.random.rand(B, N) - 0.5) * 2
        def poly(x):
            return (a @ (np.reshape(x, (-1, 1)) ** np.arange(N)).T)
        def nabla_poly(x):
            return (a[:, 1:] @ (np.arange(1, N).reshape(-1, 1) * (np.reshape(x, (-1, 1)) ** np.arange(N-1)).T))
        def nabla2_poly(x):
            return (a[:, 2:] @ (np.arange(2, N).reshape(-1, 1) * np.arange(1, N-1).reshape(-1, 1) * \
                (np.reshape(x, (-1, 1)) ** np.arange(N-2)).T))
        def integrate():
            return (a @ np.reshape(1. / np.arange(1, N+1), (-1, 1)))
        x = np.linspace(0, 1, N_grid)
        n, nabla_n, nabla2_n = poly(x), nabla_poly(x), nabla2_poly(x)
        n, nabla_n, nabla2_n = np.expand_dims(n, axis=-1), np.expand_dims(nabla_n, axis=-1), np.expand_dims(nabla2_n, axis=-1)
        m = n
        y = integrate()
        #print(np.mean(y), np.std(y))
        """y = poly(x)
        i1 = np.mean(y, axis=-1)
        print(i1, integrate())"""
        dy = np.ones_like(n)
        train_n, train_nabla_n, train_y, test_n, test_nabla_n, test_y = n[:int(0.9 * B), :, :], nabla_n[:int(0.9 * B), :, :], \
            y[:int(0.9 * B)], n[int(0.9 * B):, :, :], nabla_n[int(0.9 * B):, :, :], y[int(0.9 * B):]
        train_dy, test_dy = dy[:int(0.9 * B)], dy[int(0.9 * B):]
        train_nabla2_n, test_nabla2_n = nabla2_n[:int(0.9 * B)], nabla2_n[int(0.9 * B):]
        train_m, test_m = m[:int(0.9 * B)], m[int(0.9 * B):]
        train_n, train_nabla_n, train_y, train_dy, test_n, test_nabla_n, test_y, test_dy = torch.from_numpy(train_n).float(), \
            torch.from_numpy(train_nabla_n).float(), torch.from_numpy(train_y).float(), torch.from_numpy(train_dy).float(), torch.from_numpy(test_n).float(), \
                torch.from_numpy(test_nabla_n).float(), torch.from_numpy(test_y).float(), torch.from_numpy(test_dy).float()
        train_nabla2_n, test_nabla2_n = torch.from_numpy(train_nabla2_n).float(), torch.from_numpy(test_nabla2_n).float()
        train_m, test_m = torch.from_numpy(train_m).float(), torch.from_numpy(test_m).float()
        return train_n, train_nabla_n, train_nabla2_n, train_m, train_y, train_dy, test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy

    def polynomial1(self, B=10000, N=20, N_grid=1000):
        a = (np.random.rand(B, N) - 0.5) * 2
        def poly(x):
            return (a @ (np.reshape(x, (-1, 1)) ** np.arange(N)).T)
        def nabla_poly(x):
            return (a[:, 1:] @ (np.arange(1, N).reshape(-1, 1) * (np.reshape(x, (-1, 1)) ** np.arange(N-1)).T))
        def nabla2_poly(x):
            return (a[:, 2:] @ (np.arange(2, N).reshape(-1, 1) * np.arange(1, N-1).reshape(-1, 1) * \
                (np.reshape(x, (-1, 1)) ** np.arange(N-2)).T))
        def integrand(x):
            return (a @ (np.arange(N).reshape(-1, 1) * (np.reshape(x, (-1, 1)) ** np.arange(N)).T))
        def integrate():
            return (a[:, 1:] @ np.reshape(np.arange(1, N) / (np.arange(2, N+1) + 0.0), (-1, 1)))
        x = np.linspace(0, 1, N_grid)
        n, nabla_n, nabla2_n = poly(x), nabla_poly(x), nabla2_poly(x)
        n, nabla_n, nabla2_n = np.expand_dims(n, axis=-1), np.expand_dims(nabla_n, axis=-1), np.expand_dims(nabla2_n, axis=-1)
        y = integrate()
        m = x.reshape(1, -1, 1) * nabla_n
        """print(np.mean(y), np.std(y))
        y = integrand(np.linspace(0, 1, 10000))
        i1 = np.mean(y, axis=-1)
        print(i1, integrate())"""
        dy = -np.ones_like(n)
        train_n, train_nabla_n, train_y, test_n, test_nabla_n, test_y = n[:int(0.9 * B), :, :], nabla_n[:int(0.9 * B), :, :], \
            y[:int(0.9 * B)], n[int(0.9 * B):, :, :], nabla_n[int(0.9 * B):, :, :], y[int(0.9 * B):]
        train_dy, test_dy = dy[:int(0.9 * B)], dy[int(0.9 * B):]
        train_nabla2_n, test_nabla2_n = nabla2_n[:int(0.9 * B)], nabla2_n[int(0.9 * B):]
        train_m, test_m = m[:int(0.9 * B)], m[int(0.9 * B):]
        train_n, train_nabla_n, train_y, train_dy, test_n, test_nabla_n, test_y, test_dy = torch.from_numpy(train_n).float(), \
            torch.from_numpy(train_nabla_n).float(), torch.from_numpy(train_y).float(), torch.from_numpy(train_dy).float(), torch.from_numpy(test_n).float(), \
                torch.from_numpy(test_nabla_n).float(), torch.from_numpy(test_y).float(), torch.from_numpy(test_dy).float()
        train_nabla2_n, test_nabla2_n = torch.from_numpy(train_nabla2_n).float(), torch.from_numpy(test_nabla2_n).float()
        train_m, test_m = torch.from_numpy(train_m).float(), torch.from_numpy(test_m).float()
        return train_n, train_nabla_n, train_nabla2_n, train_m, train_y, train_dy, test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy

    def RFF(self, B=10000, N=20, N_grid=1000):
        a = (np.random.rand(B, N, 1) - 0.5) * 2
        b = np.random.rand(B, N, 1) * 2 + 0.1
        def sinosoid(x):
            return np.sum(a * np.cos(b @ np.reshape(x, (1, -1))), axis=1)
        def nabla_sin(x):
            return - np.sum(b * a * np.sin(b @ np.reshape(x, (1, -1))), axis=1)
        def nabla2_sin(x):
            return - np.sum(b * b * a * np.cos(b @ np.reshape(x, (1, -1))), axis=1)
        def integrate(x):
            return np.sum(a / b * np.sin(b @ np.reshape(x, (1, -1))), axis=1)
        x = np.linspace(0, 1, N_grid)
        n, nabla_n, nabla2_n = sinosoid(x), nabla_sin(x), nabla2_sin(x)
        #print(n.mean(-1))
        n, nabla_n, nabla2_n = np.expand_dims(n, axis=-1), np.expand_dims(nabla_n, axis=-1), np.expand_dims(nabla2_n, axis=-1)
        y = integrate(np.ones(1)) - integrate(np.zeros(1))
        m = n
        #print(y)
        print(np.mean(y), np.std(y), np.max(y))
        #y = poly(x)
        #i1 = jnp.mean(y, axis=-1)
        #print(i1, integrate())
        dy = np.ones_like(n)
        train_n, train_nabla_n, train_y, test_n, test_nabla_n, test_y = n[:int(0.9 * B), :, :], nabla_n[:int(0.9 * B), :, :], \
            y[:int(0.9 * B)], n[int(0.9 * B):, :, :], nabla_n[int(0.9 * B):, :, :], y[int(0.9 * B):]
        train_dy, test_dy = dy[:int(0.9 * B)], dy[int(0.9 * B):]
        train_nabla2_n, test_nabla2_n = nabla2_n[:int(0.9 * B)], nabla2_n[int(0.9 * B):]
        train_m, test_m = m[:int(0.9 * B)], m[int(0.9 * B):]
        train_n, train_nabla_n, train_y, train_dy, test_n, test_nabla_n, test_y, test_dy = torch.from_numpy(train_n).float(), \
            torch.from_numpy(train_nabla_n).float(), torch.from_numpy(train_y).float(), torch.from_numpy(train_dy).float(), torch.from_numpy(test_n).float(), \
                torch.from_numpy(test_nabla_n).float(), torch.from_numpy(test_y).float(), torch.from_numpy(test_dy).float()
        train_nabla2_n, test_nabla2_n = torch.from_numpy(train_nabla2_n).float(), torch.from_numpy(test_nabla2_n).float()
        train_m, test_m = torch.from_numpy(train_m).float(), torch.from_numpy(test_m).float()
        return train_n, train_nabla_n, train_nabla2_n, train_m, train_y, train_dy, test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy
    
    def RFF1(self, B=10000, N=20, N_grid=1000):
        a = (np.random.rand(B, N, 1) - 0.5) * 2
        b = np.random.rand(B, N, 1) * 2 + 0.1
        def sinosoid(x):
            return np.sum(a * np.cos(b @ np.reshape(x, (1, -1))), axis=1)
        def nabla_sin(x):
            return - np.sum(b * a * np.sin(b @ np.reshape(x, (1, -1))), axis=1)
        def nabla2_sin(x):
            return - np.sum(b * b * a * np.cos(b @ np.reshape(x, (1, -1))), axis=1)
        def integrate(x):
            return np.sum(a / b * np.sin(b @ np.reshape(x, (1, -1))), axis=1)
        def integrand(x):
            x = np.reshape(x, (1, -1))
            return - np.sum(b * a * np.sin(b @ x) * x, axis=1)
        x = np.linspace(0, 1, N_grid)
        n, nabla_n, nabla2_n = sinosoid(x), nabla_sin(x), nabla2_sin(x)
        #print(integrand(x).mean(-1))
        n, nabla_n, nabla2_n = np.expand_dims(n, axis=-1), np.expand_dims(nabla_n, axis=-1), np.expand_dims(nabla2_n, axis=-1)
        y = sinosoid(np.ones(1)) - integrate(np.ones(1)) + integrate(np.zeros(1))
        #print(y)
        m = x.reshape(1, -1, 1) * nabla_n
        #print(x.shape, nabla_n.shape, m.shape)
        print(np.mean(y), np.std(y), np.max(y))
        #y = poly(x)
        #i1 = jnp.mean(y, axis=-1)
        #print(i1, integrate())
        dy = -np.ones_like(n)
        train_n, train_nabla_n, train_y, test_n, test_nabla_n, test_y = n[:int(0.9 * B), :, :], nabla_n[:int(0.9 * B), :, :], \
            y[:int(0.9 * B)], n[int(0.9 * B):, :, :], nabla_n[int(0.9 * B):, :, :], y[int(0.9 * B):]
        train_dy, test_dy = dy[:int(0.9 * B)], dy[int(0.9 * B):]
        train_nabla2_n, test_nabla2_n = nabla2_n[:int(0.9 * B)], nabla2_n[int(0.9 * B):]
        train_m, test_m = m[:int(0.9 * B)], m[int(0.9 * B):]
        train_n, train_nabla_n, train_y, train_dy, test_n, test_nabla_n, test_y, test_dy = torch.from_numpy(train_n).float(), \
            torch.from_numpy(train_nabla_n).float(), torch.from_numpy(train_y).float(), torch.from_numpy(train_dy).float(), torch.from_numpy(test_n).float(), \
                torch.from_numpy(test_nabla_n).float(), torch.from_numpy(test_y).float(), torch.from_numpy(test_dy).float()
        train_nabla2_n, test_nabla2_n = torch.from_numpy(train_nabla2_n).float(), torch.from_numpy(test_nabla2_n).float()
        train_m, test_m = torch.from_numpy(train_m).float(), torch.from_numpy(test_m).float()
        return train_n, train_nabla_n, train_nabla2_n, train_m, train_y, train_dy, test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy

class FunctionalDataset(TensorDataset):
    def __init__(self, n, nabla_n, nabla2_n, m, y, dy):
        self.n = n
        self.nabla_n = nabla_n
        self.nabla2_n = nabla2_n
        self.y = y
        self.dy = dy
        self.m = m

    def __len__(self):
        return len(self.n)

    def __getitem__(self, idx):
        return self.n[idx], self.nabla_n[idx], self.nabla2_n[idx], self.m[idx], self.y[idx], self.dy[idx]

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Neural Functional Project')
    parser.add_argument('--N_data', type=int, default=1100)
    parser.add_argument('--N_grid', type=int, default=256)
    parser.add_argument('--dataset', type=str, default="poly")
    parser.add_argument('--batch_size', type=int, default=1000)
    parser.add_argument('--epochs', type=int, default=10001)
    parser.add_argument('--lam_f', type=float, default=0)
    parser.add_argument('--order', type=int, default=0)
    args = parser.parse_args()
    model = FNO1d(16, 64).cuda()
    if args.order == 0 and args.dataset == "poly":
        train_n, train_nabla_n, train_nabla2_n, train_m, train_y, train_dy, test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy = model.polynomial(B=args.N_data, N_grid=args.N_grid)
    elif args.order == 1 and args.dataset == "poly":
        train_n, train_nabla_n, train_nabla2_n, train_m, train_y, train_dy, test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy = model.polynomial1(B=args.N_data, N_grid=args.N_grid)
    elif args.order == 0 and args.dataset == "sin":
        train_n, train_nabla_n, train_nabla2_n, train_m, train_y, train_dy, test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy = model.RFF(B=args.N_data, N_grid=args.N_grid)
    elif args.order == 1 and args.dataset == "sin":
        train_n, train_nabla_n, train_nabla2_n, train_m, train_y, train_dy, test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy = model.RFF1(B=args.N_data, N_grid=args.N_grid)
    #print(train_n.shape, train_nabla_n.shape, train_y.shape, train_dy.shape)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)
    train_dataloader = FunctionalDataset(train_n, train_nabla_n, train_nabla2_n, train_m, train_y, train_dy)
    train_dataloader = DataLoader(train_dataloader, batch_size=args.batch_size, shuffle=True)
    test_dataloader = FunctionalDataset(test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy)
    test_dataloader = DataLoader(test_dataloader, batch_size=args.batch_size, shuffle=False)

    for epoch in tqdm(range(args.epochs)):
        model.train()
        optimizer.zero_grad()
        for n, nabla_n, nabla2_n, m, y, dy in train_dataloader:
            n, y, nabla_n, nabla2_n, dy = n.cuda().requires_grad_(), y.cuda().requires_grad_(), nabla_n.cuda().requires_grad_(), nabla2_n.cuda().requires_grad_(), dy.cuda()
            x = model.get_grid(n.shape, n.device).requires_grad_()
            m = m.cuda()
            out = model(x, n, nabla_n)
            l2 = torch.nn.MSELoss()(out.view(-1), m.view(-1))#myloss(out.view(-1), train_y.view(-1))
            if args.lam_f > 0:
                #out_d = torch.autograd.grad(out.sum(), n, create_graph=True)[0]
                out_d = model.FD(x, n, nabla_n, nabla2_n)
                l2 += args.lam_f * torch.nn.MSELoss()(out_d.view(-1), dy.view(-1))
            l2.backward() # use the l2 relative loss
            optimizer.step()

        if epoch%1000==0:
            pred, pred_f, pred_i = [], [], []
            for n, nabla_n, nabla2_n, m, y, dy in test_dataloader:
                n, y, nabla_n, nabla2_n, dy = n.cuda().requires_grad_(), y.cuda().requires_grad_(), nabla_n.cuda().requires_grad_(), nabla2_n.cuda().requires_grad_(), dy.cuda()
                x = model.get_grid(n.shape, n.device).requires_grad_()
                m = m.cuda()
                out = model(x, n, nabla_n)
                pred.append(out.view(-1).detach().cpu().numpy())
                out = out.mean(1)
                pred_i.append(out.view(-1).detach().cpu().numpy())
                pred_dy = model.FD(x, n, nabla_n, nabla2_n)
                pred_f.append(pred_dy.detach().cpu().numpy())
            pred = np.concatenate(pred)
            pred_f = np.concatenate(pred_f, axis=0)
            pred_i = np.concatenate(pred_i)

            te_loss = np.linalg.norm(pred - test_m.view(-1).numpy()) / np.linalg.norm(test_m.view(-1).numpy())
            te_i = np.linalg.norm(pred_i - test_y.view(-1).numpy()) / np.linalg.norm(test_y.view(-1).numpy())
            te_loss_f = np.linalg.norm(pred_f.reshape(-1) - test_dy.view(-1).numpy()) / np.linalg.norm(test_dy.view(-1).numpy())
            print('epoch %d, loss: %E, err_func: %E, err_intor: %E, err_FD: %E'%(epoch, l2, te_loss, te_i, te_loss_f))