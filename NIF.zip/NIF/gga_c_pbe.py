import jax
import jax.numpy as jnp


def integrand_gga_c_pbe(rho, nabla_rho):
    """GGA_C_PBE
  https://gitlab.com/libxc/libxc/-/blob/master/maple/gga_exc/gga_c_pbe.mpl
  """
    beta = 0.06672455060314922
    gamma = (1 - jnp.log(2)) / (jnp.pi**2)

    params_a_pp = [1, 1, 1]  # NOQA: F841
    params_a_a = [0.031091, 0.015545, 0.016887]
    params_a_alpha1 = [0.21370, 0.20548, 0.11125]
    params_a_beta1 = [7.5957, 14.1189, 10.357]
    params_a_beta2 = [3.5876, 6.1977, 3.6231]
    params_a_beta3 = [1.6382, 3.3662, 0.88026]
    params_a_beta4 = [0.49294, 0.62517, 0.49671]
    params_a_fz20 = 1.709921

    def phi(zeta):
        return (((1 + zeta)**2 + 1e-40)**(1 / 3) +
                ((1 - zeta)**2 + 1e-40)**(1 / 3)) / 2

    def f_zeta(zeta):
        """
    Eq. (9) of Perdew1992_13244
    https://gitlab.com/libxc/libxc/-/blob/master/maple/util.mpl
    """
        return ((1 + zeta)**(4 / 3) +
                ((1 - zeta)**4 + 1e-40)**(1 / 3) - 2) / (2**(4 / 3) - 2)

    def f_pw(n):
        """
    Eq. (8) of Perdew1992_13244
    https://gitlab.com/libxc/libxc/-/blob/master/maple/lda_exc/lda_c_pw.mpl
    """

        # Denominator of Eq. 10 of Perdew1992_13244
        def g_aux(k, r_s):
            return params_a_beta1[k] * (r_s + 1e-40)**(
                1 / 2) + params_a_beta2[k] * r_s + params_a_beta3[k] * (
                    r_s + 1e-40)**(3 / 2) + params_a_beta4[k] * (r_s)**2

        def g(k, r_s):
            return -2 * params_a_a[k] * (
                1 + params_a_alpha1[k] * r_s) * jnp.log(
                    jnp.where(
                        1 + 1 / (2 * params_a_a[k] * g_aux(k, r_s)) < 1e-20,
                        1e-20, 1 + 1 / (2 * params_a_a[k] * g_aux(k, r_s))))

        r_s = (3 / (4 * jnp.pi * n + 1e-40) + 1e-40)**(1 / 3)
        zeta = 0
        return g(0, r_s) + zeta**4 * f_zeta(zeta) * (g(1, r_s) - g(0, r_s) + g(
            2, r_s) / params_a_fz20) - f_zeta(zeta) * g(2, r_s) / params_a_fz20

    def epsilon_X_unif(n):
        """
    Eq. (10) in PBE paper.
    """
        k_F = (3 * jnp.pi**2 * n + 1e-40)**(1 / 3)
        return -3 * k_F / (4 * jnp.pi)

    def capital_a(n):
        """
    Eq. (8) in PBE paper.
    """
        zeta = 0
        denom = jnp.exp(-f_pw(n) / (gamma * phi(zeta)**3 + 1e-20)) - 1
        return beta / (gamma * denom + 1e-20)

    def helper(n, t):
        """Helpers for equation (7): t^2 + At^4.
    This is the factor in the numerator of the second term, once you
    pull in the t^2 factor in front of the fraction.
    """
        return t**2 + capital_a(n) * (t**4)

    def second_term(n, t):
        """Second term in equation (7), after the sign +.
    Re-organized by pushing t^2 to numerator.
    """
        return beta * helper(
            n, t) / (gamma * (1 + capital_a(n) * helper(n, t)) + 1e-20)

    def h(n, nabla_n):
        """Equation (7) in PBE paper.
    """
        k_F = (3 * jnp.pi**2 * n + 1e-20)**(1 / 3)
        k_s = jnp.sqrt(4 * k_F / jnp.pi + 1e-20)
        zeta = 0
        t_fn = jnp.sqrt(jnp.sum(nabla_n**2) +
                        1e-40) / (2 * phi(zeta) * k_s * n + 1e-20)
        return gamma * phi(zeta)**3 * jnp.log(
            jnp.where(1 + second_term(n, t_fn) < 1e-20, 1e-20,
                      1 + second_term(n, t_fn)))

    def v(n, nabla_n):
        return (h(n, nabla_n) + f_pw(n)) * n

    return v(rho, nabla_rho)
