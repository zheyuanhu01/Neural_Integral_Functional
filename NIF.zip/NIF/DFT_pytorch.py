"""Main wrapper for D4FT"""

import os

from absl import app, flags, logging
from jax.config import config

import d4ft
import d4ft.geometries
from d4ft.functions import wave2density
from d4ft.energy import energy_gs, integrand_kinetic, integrand_external, integrand_hartree, integrand_x_lsda
from d4ft.hamiltonian import *

import numpy as np
import jax.numpy as jnp
import jax
from tqdm import tqdm
from FNO import *
import matplotlib.pyplot as plt

FLAGS = flags.FLAGS

flags.DEFINE_integer("batch_size", 200, "batch size")
flags.DEFINE_integer("epoch", 10001, "epoch")
flags.DEFINE_float("converge_threshold", 1e-8, "")
flags.DEFINE_float("lr", 1e-3, "learning rate for sgd")
flags.DEFINE_float("momentum", 5e-2, "momentum for scf")
flags.DEFINE_bool("pre_cal", False, "whether to pre-calculate the integrals")
flags.DEFINE_integer("seed", 137, "random seed")
flags.DEFINE_integer("spin", 0, "total spin")
flags.DEFINE_string("geometry", "h2", "")
flags.DEFINE_string("opt", "adam", "optimizer")
flags.DEFINE_string("basis_set", "sto-3g", "which basis set to use")
flags.DEFINE_string("device", "0", "cuda visible device")
flags.DEFINE_bool("lr_decay", True, "whether to use a piecewise linear")
flags.DEFINE_string("xc", "lda", "exchange functional")
flags.DEFINE_integer("quad_level", 1, "number of the quadrature points")
flags.DEFINE_bool("use_f64", False, "whether to use float64")
flags.DEFINE_bool("debug_nans", False, "whether to enable nan debugging in jax")
flags.DEFINE_enum("algo", "sgd", ["sgd", "scf"], "which algorithm to use")

flags.DEFINE_float("lam_f", 0.0, "")
flags.DEFINE_integer("size", 512, "")
flags.DEFINE_integer("N_data", 1000, "")
flags.DEFINE_string("energy", "hartree", "")

def main(_):
  os.environ["CUDA_VISIBLE_DEVICES"] = FLAGS.device

  logging.set_verbosity(logging.INFO)

  config.update("jax_enable_x64", FLAGS.use_f64)
  config.update("jax_debug_nans", FLAGS.debug_nans)

  geometry = getattr(d4ft.geometries, FLAGS.geometry + "_geometry")
  mol = d4ft.Molecule(
    geometry,
    spin=FLAGS.spin,
    level=FLAGS.quad_level,
    basis=FLAGS.basis_set,
    algo=FLAGS.algo,
    xc=FLAGS.xc
  )

  n, nabla_n, nabla2_n, y, e, h = [], [], [] ,[], [], []

  x, w = np.asarray(mol.grids), np.asarray(mol.weights)
  N_grid = np.shape(x)[0]
  idx = np.random.choice(N_grid, size=FLAGS.size, replace=False)
  x, w = x[idx], w[idx]
  w = w.reshape(1, -1, 1) / FLAGS.size * len(mol.grids)

  @jax.jit
  def data_generation(params):
    def mo(r):
      return mol.mo(params, r) * mol.nocc
    rho = wave2density(mo)
    nabla_rho = jax.vmap(jax.grad(rho), in_axes=(0))
    nabla2_rho = jax.vmap(jax.hessian(rho), in_axes=(0))
    rho = jax.vmap(rho, in_axes=(0))
    
    n_, nabla_n_, nabla2_n_ = rho(x), nabla_rho(x), nabla2_rho(x).reshape(-1, 9)

    e_total, e = energy_gs(mo, mol.nuclei, (mol.grids, mol.weights))
    e_kin, e_ext, e_xc, e_hartree, e_nuc = e
    
    y_kin = jax.vmap(integrand_kinetic(mo))(x)
    y_ext = jax.vmap(integrand_external(mo, mol.nuclei))(x)
    y_xc = jax.vmap(integrand_x_lsda(mo))(x)
    y_hartree = hamil_hartree(mo, (mol.grids, mol.weights), x) * rho(x) / 2# jax.vmap(integrand_hartree(mo))(x)

    h_ext = hamil_external(mol.nuclei, x)
    h_xc = hamil_lda(mo, x)
    h_hartree = hamil_hartree(mo, (mol.grids, mol.weights), x) 

    return n_, nabla_n_, nabla2_n_, [y_kin, y_ext, y_xc, y_hartree], [e_kin, e_ext, e_xc, e_hartree], [h_ext, h_xc, h_hartree]

  for seed in tqdm(range(FLAGS.N_data)):
    params = mol._init_param(seed)
    n_, nabla_n_, nabla2_n_, y_, e_, h_ = data_generation(params)
    n.append(n_)
    nabla_n.append(nabla_n_)
    nabla2_n.append(nabla2_n_)
    y.append(y_)
    e.append(e_)
    h.append(h_)

  n, nabla_n, nabla2_n, y, dy, e = np.expand_dims(np.asarray(n), -1), np.asarray(nabla_n), np.asarray(nabla2_n), np.asarray(y).transpose(0, 2, 1), np.asarray(h).transpose(0, 2, 1), np.asarray(e)
  print(n.shape, nabla_n.shape, nabla2_n.shape, y.shape, dy.shape, e.shape)
  if FLAGS.energy == "kin":
    y, dy, e = y[:, :, 0:1], dy[:, :, 0:1], e[:, 0:1]
  elif FLAGS.energy == "ext":
    y, dy, e = y[:, :, 1:2], dy[:, :, 0:1], e[:, 1:2]
  elif FLAGS.energy == "xc":
    y, dy, e = y[:, :, 2:3], dy[:, :, 1:2], e[:, 2:3]
  elif FLAGS.energy == "hartree":
    y, dy, e = y[:, :, 3:4], dy[:, :, 2:3], e[:, 3:4]
  n = torch.from_numpy(n).float()
  nabla_n = torch.from_numpy(nabla_n).float()
  nabla2_n = torch.from_numpy(nabla2_n).float()
  y = torch.from_numpy(y).float()
  dy = torch.from_numpy(dy).float()
  e = torch.from_numpy(e).float()

  length = n.shape[0]
  train_n, test_n = n[:int(0.9 * length)], n[int(0.9 * length):]
  train_nabla_n, test_nabla_n = nabla_n[:int(0.9 * length)], nabla_n[int(0.9 * length):]
  train_nabla2_n, test_nabla2_n = nabla2_n[:int(0.9 * length)], nabla2_n[int(0.9 * length):]
  train_y, test_y = y[:int(0.9 * length)], y[int(0.9 * length):]
  train_dy, test_dy = dy[:int(0.9 * length)], dy[int(0.9 * length):]
  train_e, test_e = e[:int(0.9 * length)], e[int(0.9 * length):]

  ### Define model
  model = FNO1d(16, 64).cuda()
  optimizer = torch.optim.Adam(model.parameters(), lr=FLAGS.lr, weight_decay=1e-4)
  train_dataloader = FunctionalDataset3D(train_n, train_nabla_n, train_nabla2_n, train_y, train_dy, train_e)
  train_dataloader = DataLoader(train_dataloader, batch_size=FLAGS.batch_size, shuffle=True)
  test_dataloader = FunctionalDataset3D(test_n, test_nabla_n, test_nabla2_n, test_y, test_dy, test_e)
  test_dataloader = DataLoader(test_dataloader, batch_size=FLAGS.batch_size, shuffle=False)

  x = torch.from_numpy(x).float()
  x = x.reshape(1, -1, 3)

  for epoch in tqdm(range(FLAGS.epoch)):
      model.train()
      optimizer.zero_grad()
      for n, nabla_n, nabla2_n, y, dy, e in train_dataloader:
          batchsize = n.shape[0]
          x_ = x.repeat([batchsize, 1, 1])
          x1, x2, x3 = x_[:, :, 0:1], x_[:, :, 1:2], x_[:, :, 2:3]
          x1, x2, x3 = x1.cuda().requires_grad_(), x2.cuda().requires_grad_(), x3.cuda().requires_grad_()
          nabla_n1, nabla_n2, nabla_n3 = nabla_n[:, :, 0:1], nabla_n[:, :, 1:2], nabla_n[:, :, 2:3]
          n, y, nabla2_n, dy = n.cuda().requires_grad_(), y.cuda().requires_grad_(), nabla2_n.cuda().requires_grad_(), dy.cuda()
          nabla_n1, nabla_n2, nabla_n3 = nabla_n1.cuda().requires_grad_(), nabla_n2.cuda().requires_grad_(), nabla_n3.cuda().requires_grad_()
          out = model(x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3) # batch, size, 4
          l2 = torch.nn.MSELoss()(out.view(-1), y.view(-1))
          if FLAGS.lam_f > 0.0:
              out_d = torch.autograd.grad(out, n, create_graph=True, grad_outputs=torch.ones_like(out))[0] # [batch, N_grid, 1]
              l2 += FLAGS.lam_f * torch.nn.MSELoss()(out_d.view(-1), dy.view(-1))
          l2.backward()
          optimizer.step()

      if epoch%1000==0:
          pred, pred_e = [], []
          pred_f, true_f = [], []
          for n, nabla_n, nabla2_n, y, dy, e in test_dataloader:
            batchsize = n.shape[0]
            x_ = x.repeat([batchsize, 1, 1])
            x1, x2, x3 = x_[:, :, 0:1], x_[:, :, 1:2], x_[:, :, 2:3]
            x1, x2, x3 = x1.cuda().requires_grad_(), x2.cuda().requires_grad_(), x3.cuda().requires_grad_()
            nabla_n1, nabla_n2, nabla_n3 = nabla_n[:, :, 0:1], nabla_n[:, :, 1:2], nabla_n[:, :, 2:3]
            n, y, nabla2_n, dy = n.cuda().requires_grad_(), y.cuda().requires_grad_(), nabla2_n.cuda().requires_grad_(), dy.cuda()
            nabla_n1, nabla_n2, nabla_n3 = nabla_n1.cuda().requires_grad_(), nabla_n2.cuda().requires_grad_(), nabla_n3.cuda().requires_grad_()
            out = model(x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3)
            pred_dy = torch.autograd.grad(out, n, create_graph=True, grad_outputs=torch.ones_like(out))[0] # model.FD(x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3, nabla2_n)
            out = out.detach().cpu().numpy()
            e = np.sum(out * w, axis=1)
            pred.append(out)
            pred_e.append(e)
            pred_f.append(pred_dy.detach().cpu().numpy())
            true_f.append(dy.detach().cpu().numpy())
          pred, pred_e = np.concatenate(pred), np.concatenate(pred_e)
          pred_f, true_f = np.concatenate(pred_f, axis=0), np.concatenate(true_f, axis=0)

          relative_l2 = np.linalg.norm(pred.reshape(-1) - test_y.reshape(-1).numpy()) / np.linalg.norm(test_y.reshape(-1).numpy())
          relative_e = np.linalg.norm(pred_e.reshape(-1) - test_e.reshape(-1).numpy()) / np.linalg.norm(test_e.reshape(-1).numpy())
          te_loss_f = np.linalg.norm(pred_f.reshape(-1) - true_f.reshape(-1)) / np.linalg.norm(true_f.reshape(-1))
          print('epoch %d, loss: %g, error_f: %g, error_h: %g, error_e: %g'%(epoch, l2, relative_l2, te_loss_f, relative_e))

if __name__ == '__main__':
  app.run(main)
