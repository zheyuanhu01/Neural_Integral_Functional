# Copyright 2022 Garena Online Private Limited
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import jax
import jax.numpy as jnp
from d4ft.energy import energy_gs, wave2density, integrand_kinetic, integrand_hartree
from typing import Callable
from absl import logging
  
def hamil_external(nuclei, x):
  r"""
  \int \phi_i \nabla^2 \phi_j dx
  Args:
    mo (Callable): a [3] -> [2, N] function
    batch: a tuple (grids, weights)
  Return:
    [2, N, N] Array
  """
  nuclei_loc = nuclei['loc']
  nuclei_charge = nuclei['charge']

  def v(r):
    return -jnp.sum(
      nuclei_charge / jnp.sqrt(jnp.sum((r - nuclei_loc)**2, axis=1) + 1e-16)
    )

  v = jax.vmap(v, in_axes=0)

  return v(x)


def hamil_hartree(mo_old, batch, x):
  density = wave2density(mo_old)

  def g(r):
    r"""
      g(r) = \int n(r')/|r-r'| dr'
    """

    def v(x):
      return density(x) / jnp.clip(
        jnp.linalg.norm(x - r), a_min=1e-9
      ) * jnp.any(x != r)

    return integrate_s(v, batch)
  
  g = jax.vmap(g, in_axes=0)

  return g(x)


def energy_hartree(mo_old, batch):
  density = wave2density(mo_old)

  def g(r):
    r"""
      g(r) = \int n(r')/|r-r'| dr'
    """

    def v(x):
      return density(x) / jnp.clip(
        jnp.linalg.norm(x - r), a_min=1e-9
      ) * jnp.any(x != r) / 2

    return integrate_s(v, batch)
  
  return integrate_s(g, batch)


def hamil_lda(mo_old, x):
  """
  v_xc = -(3/pi n(r))^(1/3)
  Return:
    [2, N, N] array
  """
  density = wave2density(mo_old)

  def g(n):
    return -(3 / jnp.pi * n)**(1 / 3)
  
  v = lambda r: g(density(r))
  v = jax.vmap(v)

  return v(x)


"""def hamil_gga(x, rho, nabla_rho, nabla2_rho):
  m = 1. / 15
  const = -3 / 4 * (3 / jnp.pi)**(1 / 3)
  k_F = (3 * jnp.pi**2)**(1. / 3)
  t = jnp.sqrt(jnp.sum(nabla_rho**2)) / (2 * k_F) # /rho**(4/3)
  ret1 = 4./3 * const * rho**(1 / 3 - 8 / 15) * (rho**8 + 0.0864 * t**2 * rho**(16 / 3) / m + 14 * t**4 * rho**(8 / 3) + 0.2 * t**6)**m
  t = t / rho
  temp1 = (rho**2 + 0.0864 * t**2 * rho**(4 / 3) / m + 14 * t**4 * rho**(2 / 3) + 0.2 * t**6)**(m - 1) # * rho**(8 * (1 - m))
  temp2 = (2 * 0.0864 * t * rho**(4 / 3) / m + 4 * 14 * t**3 * rho**(2 / 3) + 6 * 0.2 * t**5)# / rho**(20. / 3)
  ret2 = -4./3 * t * const * m * rho**(1./3 - 2*m) * temp1 * temp2
  return ret1 + ret2"""
def hamil_gga(x, rho, nabla_rho, nabla2_rho):
  def integrand_x_gga(x, rho, nabla_rho):
    kappa, mu = 0.967, 0.235
    const = -3 / 4 * (3 / jnp.pi)**(1 / 3)
    k_F = (3 * jnp.pi**2)**(1. / 3)
    t2 = (jnp.sum(nabla_rho**2)) / (2 * k_F)**2
    return const * rho**(4./3) + kappa**2/(1 + kappa) * const * rho**4 / (kappa * rho**(8./3) + mu * t2)
    
  n, nabla_n, nabla2_n = rho, nabla_rho, nabla2_rho

  y_n = jax.grad(integrand_x_gga, argnums=1)(x, n, nabla_n)
  temp2 = jax.grad(jax.grad(integrand_x_gga, argnums=1), argnums=2)(x, n, nabla_n)
  temp2 = jnp.dot(temp2, nabla_n)
  nabla2_n = jnp.reshape(nabla2_n, (-1, 3, 3))
  temp3 = jax.hessian(integrand_x_gga, argnums=2)(x, n, nabla_n)
  temp3 = jnp.sum(temp3 * nabla2_n)

  return y_n #- temp2 - temp3

def integrate_s(integrand: Callable, batch):
  '''
  Integrate a [3] -> [2, N, ...] function.
  '''
  g, w = batch

  def v(r, w):
    return integrand(r) * w

  @jax.jit
  def f(g, w):
    return jnp.sum(jax.vmap(v)(g, w), axis=0)

  return f(g, w)
