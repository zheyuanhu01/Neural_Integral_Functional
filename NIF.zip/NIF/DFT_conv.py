"""Main wrapper for D4FT"""

import os

from absl import app, flags, logging
from jax.config import config

import d4ft
import d4ft.geometries
from d4ft.functions import wave2density
from d4ft.energy import energy_gs, integrand_kinetic, integrand_external, integrand_hartree, integrand_x_lsda
from d4ft.energy import energy_lsda, energy_gga, integrand_gga_x_pbe
from d4ft.hamiltonian import *

import numpy as np
import jax.numpy as jnp
import jax
import jax.random as jrdm
from tqdm import tqdm
import matplotlib.pyplot as plt
import haiku as hk
import optax

class MLP(hk.Module):
    def __init__(self, layers):
        super().__init__()
        self.layers = layers

    def __call__(self, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3):
        x = jnp.hstack([x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3])
        for dim in self.layers[:-1]:
            x = hk.Linear(dim)(x)
            x = jax.nn.gelu(x)
        x = hk.Linear(self.layers[-1])(x)
        return x[0]

FLAGS = flags.FLAGS

flags.DEFINE_integer("batch_size", 1100, "batch size")
flags.DEFINE_integer("epoch", 200001, "epoch")
flags.DEFINE_float("converge_threshold", 1e-8, "")
flags.DEFINE_float("lr", 1e-3, "learning rate for sgd")
flags.DEFINE_float("momentum", 5e-2, "momentum for scf")
flags.DEFINE_bool("pre_cal", False, "whether to pre-calculate the integrals")
flags.DEFINE_integer("seed", 137, "random seed")
flags.DEFINE_integer("spin", 0, "total spin")
flags.DEFINE_string("geometry", "h2", "")
flags.DEFINE_string("opt", "adam", "optimizer")
flags.DEFINE_string("basis_set", "sto-3g", "which basis set to use")
flags.DEFINE_string("device", "0", "cuda visible device")
flags.DEFINE_bool("lr_decay", True, "whether to use a piecewise linear")
flags.DEFINE_string("xc", "lda", "exchange functional")
flags.DEFINE_integer("quad_level", 0, "number of the quadrature points")
flags.DEFINE_bool("use_f64", False, "whether to use float64")
flags.DEFINE_bool("debug_nans", False, "whether to enable nan debugging in jax")
flags.DEFINE_enum("algo", "sgd", ["sgd", "scf"], "which algorithm to use")

flags.DEFINE_float("lam_f", 0.0, "")
flags.DEFINE_float("prop", 0.5, "")
flags.DEFINE_integer("size", 1192, "")
flags.DEFINE_integer("N_data", 200, "")
flags.DEFINE_string("energy", "lda", "")

flags.DEFINE_integer("FNO_width", 64, "")
flags.DEFINE_integer("FNO_modes", 16, "")
flags.DEFINE_integer("FNO_layers", 4, "")

"""
H2 110 1192
H2O 135 2278
O2 CO2 HF 168 2172
Ch4 90 3482
ethanol: 144
"""

@jax.jit
def batch_sampler(n, nabla_n, nabla2_n, y, dy, e):
  batch_size = FLAGS.batch_size
  npoint = n.shape[0]
  batchsize = min(npoint, batch_size)
  idx = np.arange(npoint)
  idx = np.random.permutation(idx)
  n, nabla_n, nabla2_n, y, dy, e = n[idx], nabla_n[idx], nabla2_n[idx], y[idx], dy[idx], e[idx]

  batch_size = min(npoint, batch_size)
  nbatch = int(npoint / batch_size)

  _n = jnp.split(n[:nbatch * batch_size], nbatch)
  _nabla_n = jnp.split(nabla_n[:nbatch * batch_size], nbatch)
  _nabla2_n = jnp.split(nabla2_n[:nbatch * batch_size], nbatch)
  _y = jnp.split(y[:nbatch * batch_size], nbatch)
  _dy = jnp.split(dy[:nbatch * batch_size], nbatch)
  _e = jnp.split(e[:nbatch * batch_size], nbatch)

  return list(zip(_n, _nabla_n, _nabla2_n, _y, _dy, _e))

def main(_):
  os.environ["CUDA_VISIBLE_DEVICES"] = FLAGS.device

  logging.set_verbosity(logging.INFO)

  config.update("jax_enable_x64", FLAGS.use_f64)
  config.update("jax_debug_nans", FLAGS.debug_nans)

  geometry = getattr(d4ft.geometries, FLAGS.geometry + "_geometry")
  mol = d4ft.Molecule(
    geometry,
    spin=FLAGS.spin,
    level=FLAGS.quad_level,
    basis=FLAGS.basis_set,
    algo=FLAGS.algo,
    xc=FLAGS.xc
  )

  n, nabla_n, nabla2_n, y, e, h = [], [], [] ,[], [], []

  x, w = np.asarray(mol.grids), np.asarray(mol.weights)
  N_grid = np.shape(x)[0]
  idx = np.random.choice(N_grid, size=FLAGS.size, replace=False)
  x, w = x[idx], w[idx]
  w = w.reshape(1, -1) # / FLAGS.size * len(mol.grids)

  @jax.jit
  def data_generation(params):
    def mo(r):
      return mol.mo(params, r) * mol.nocc
    rho = wave2density(mo)
    nabla_rho = jax.vmap(jax.grad(rho), in_axes=(0))
    nabla2_rho = jax.vmap(jax.hessian(rho), in_axes=(0))
    rho = jax.vmap(rho, in_axes=(0))
    
    n_, nabla_n_, nabla2_n_ = rho(x), nabla_rho(x), nabla2_rho(x).reshape(-1, 9)
    # print(jnp.shape(x), jnp.shape(n_), jnp.shape(nabla_n_), jnp.shape(nabla2_n_))

    if FLAGS.energy == "lda":
      e_xc = energy_lsda(mo, (mol.grids, mol.weights))
      y_xc = jax.vmap(integrand_x_lsda(mo))(x)
      h_xc = hamil_lda(mo, x)
    elif FLAGS.energy == "gga":
      def fd_gga_x_pbe(n, nabla_n, nabla2_n):
        temp1 = jax.grad(integrand_gga_x_pbe, argnums=0)(n, nabla_n)
        temp2 = jax.grad(jax.grad(integrand_gga_x_pbe, argnums=0), argnums=1)(n, nabla_n)
        print(jnp.shape(temp1), jnp.shape(temp2), jnp.shape(nabla_n), jnp.shape(nabla2_n))
        temp2 = jnp.dot(nabla_n, temp2)
        temp3 = jax.hessian(integrand_gga_x_pbe, argnums=1)(n, nabla_n)
        temp3 = jnp.sum(temp3 * jnp.reshape(nabla2_n, (3, 3)))
        return temp1 - temp2 - temp3
      y_xc = jax.vmap(integrand_gga_x_pbe)(n_, nabla_n_) # integrand_x_gga(rho, nabla_rho)(x)
      e_xc = jnp.dot(y_xc, w.reshape(-1)) # energy_gga(rho, nabla_rho, (mol.grids, mol.weights))
      h_xc = jax.vmap(fd_gga_x_pbe)(n_, nabla_n_, nabla2_n_)
    return n_, nabla_n_, nabla2_n_, y_xc, e_xc, h_xc

  for seed in tqdm(range(FLAGS.N_data)):
    params = mol._init_param(seed)
    n_, nabla_n_, nabla2_n_, y_, e_, h_ = data_generation(params)
    n.append(n_)
    nabla_n.append(nabla_n_)
    nabla2_n.append(nabla2_n_)
    y.append(y_)
    e.append(e_)
    h.append(h_)

  n, nabla_n, nabla2_n, y, dy, e = np.asarray(n), np.asarray(nabla_n), np.asarray(nabla2_n), np.asarray(y), np.asarray(h), np.asarray(e)
  print(n.shape, nabla_n.shape, nabla2_n.shape, y.shape, dy.shape, e.shape)
  print(y.max(), y.min(), y.mean(), "|", dy.max(), dy.min(), dy.mean(), "|", e.max(), e.min(), e.mean())

  prop = FLAGS.prop
  length = n.shape[0]
  train_n, test_n = n[:int(prop * length)], n[int(prop * length):]
  train_nabla_n, test_nabla_n = nabla_n[:int(prop * length)], nabla_n[int(prop * length):]
  train_nabla2_n, test_nabla2_n = nabla2_n[:int(prop * length)], nabla2_n[int(prop * length):]
  train_m, test_m = y[:int(prop * length)], y[int(prop * length):]
  train_dy, test_dy = dy[:int(prop * length)], dy[int(prop * length):]
  train_y, test_y = e[:int(prop * length)], e[int(prop * length):]

  ### Define model
  @hk.transform
  def network(x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3):
    #temp = FNO1d(FLAGS.FNO_modes, FLAGS.FNO_width, FLAGS.FNO_layers) 
    temp = MLP([FLAGS.FNO_width] * (FLAGS.FNO_layers - 1) + [1]) 
    return temp(x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3)
  net = hk.without_apply_rng(network)

  grids = np.expand_dims(x, 0)
  x = np.tile(grids, (np.shape(train_n)[0], 1, 1))
  x1, x2, x3 = x[:, :, 0], x[:, :, 1], x[:, :, 2]
  train_nabla_n1, train_nabla_n2, train_nabla_n3 = train_nabla_n[:, :, 0], train_nabla_n[:, :, 1], train_nabla_n[:, :, 2]
  key = jax.random.PRNGKey(FLAGS.seed)
  params = net.init(key, x1[0, 0], x2[0, 0], x3[0, 0], train_n[0, 0], train_nabla_n1[0, 0], train_nabla_n2[0, 0], train_nabla_n3[0, 0])
  net_pred_fn = jax.vmap(net.apply, (None, 0, 0, 0, 0, 0, 0, 0))

  def fd_pred_fn(params, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3, nabla2_n):
    y_n = jax.grad(net.apply, argnums=4)(params, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3)
    temp1 = jax.grad(jax.grad(net.apply, argnums=1), argnums=5)(params, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3)
    temp1 += jax.grad(jax.grad(net.apply, argnums=2), argnums=6)(params, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3)
    temp1 += jax.grad(jax.grad(net.apply, argnums=3), argnums=7)(params, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3)
    temp2 = jax.grad(jax.grad(net.apply, argnums=4), argnums=[5, 6, 7])(params, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3)
    temp2 = temp2[0] * nabla_n1 + temp2[1] * nabla_n2 + temp2[2] * nabla_n3
    nabla2_n = jnp.reshape(nabla2_n, (-1, 3, 3))
    temp3 = jax.hessian(net.apply, argnums=[5, 6, 7])(params, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3)
    temp3 = jnp.asarray(temp3)
    temp3 = jnp.sum(temp3 * nabla2_n)
    return y_n - temp1 - temp2 - temp3

  fd_pred_fn(params, x1[0, 0], x2[0, 0], x3[0, 0], train_n[0, 0], train_nabla_n1[0, 0], train_nabla_n2[0, 0], train_nabla_n3[0, 0], train_nabla2_n[0, 0])
  fd_pred_fn = jax.vmap(fd_pred_fn, (None, 0, 0, 0, 0, 0, 0, 0, 0))


  #lr = FLAGS.lr
  lr = optax.exponential_decay(init_value=FLAGS.lr, transition_steps=5000, decay_rate=0.9)
  optimizer = optax.adam(lr)
  opt_state = optimizer.init(params)
  train_dataloader = batch_sampler(train_n, train_nabla_n, train_nabla2_n, train_m, train_dy, train_y)
  test_dataloader = batch_sampler(test_n, test_nabla_n, test_nabla2_n, test_m, test_dy, test_y)

  @jax.jit
  def get_loss(params, x, n, nabla_n, nabla2_n, m, dy):
    x1, x2, x3 = x[:, 0], x[:, 1], x[:, 2]
    nabla_n1, nabla_n2, nabla_n3 = nabla_n[:, 0], nabla_n[:, 1], nabla_n[:, 2]
    y_pred = net_pred_fn(params, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3)
    y_pred = jnp.reshape(y_pred, (-1, FLAGS.size))
    #ret = jnp.mean((y_pred - m)**2)
    ret = jnp.sum(((1 * jnp.abs(w) + 1) * (y_pred - m))**2, axis=1)
    ret = jnp.mean(ret)
    return ret

  @jax.jit
  def get_loss_2(params, x, n, nabla_n, nabla2_n, m, dy):
    x1, x2, x3 = x[:, 0], x[:, 1], x[:, 2]
    nabla_n1, nabla_n2, nabla_n3 = nabla_n[:, 0], nabla_n[:, 1], nabla_n[:, 2]
    y_pred = net_pred_fn(params, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3)
    y_pred = jnp.reshape(y_pred, (-1, FLAGS.size))
    ret = jnp.sum(((1 * jnp.abs(w) + 1) * (y_pred - m))**2, axis=1)
    ret = jnp.mean(ret)
    #ret = jnp.linalg.norm(y_pred - m, axis=-1) / jnp.linalg.norm(m, axis=-1)
    #ret = jnp.mean(ret)
    if FLAGS.lam_f > 0:
      f_pred = fd_pred_fn(params, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3, nabla2_n)
      f_pred = jnp.reshape(f_pred, (-1, FLAGS.size))
      ret += FLAGS.lam_f * jnp.mean(jnp.sum(((0 * jnp.abs(w) + 1) * (f_pred - dy))**2, axis=1))
    return ret
  
  @jax.jit
  def test_loss(params, n, nabla_n, nabla2_n, m, y, dy):
    x = jnp.tile(grids, (jnp.shape(n)[0], 1, 1)) # get_grid(jnp.shape(n))
    x = jnp.reshape(x, (-1, 3))
    n, nabla_n, nabla2_n = n.reshape(-1), nabla_n.reshape(-1, 3), nabla2_n.reshape(-1, 9)
    x1, x2, x3 = x[:, 0], x[:, 1], x[:, 2]
    nabla_n1, nabla_n2, nabla_n3 = nabla_n[:, 0], nabla_n[:, 1], nabla_n[:, 2]
    y_pred = net_pred_fn(params, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3)
    i_pred = jnp.sum(w * jnp.reshape(y_pred, (-1, FLAGS.size)), axis=1) / FLAGS.size * len(mol.grids)
    i = jnp.sum(w * m, axis=1) / FLAGS.size * len(mol.grids)
    f_pred = fd_pred_fn(params, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3, nabla2_n)
    return y_pred, i_pred, f_pred, i

  @jax.jit
  def step(params, opt_state, n, nabla_n, nabla2_n, m, dy):
    x = jnp.tile(grids, (jnp.shape(n)[0], 1, 1))
    x = jnp.reshape(x, (-1, 3))
    n, nabla_n, nabla2_n = n.reshape(-1), nabla_n.reshape(-1, 3), nabla2_n.reshape(-1, 9)
    current_loss, gradients = jax.value_and_grad(get_loss)(params, x, n, nabla_n, nabla2_n, m, dy)
    updates, opt_state = optimizer.update(gradients, opt_state)
    params = optax.apply_updates(params, updates)
    return current_loss, params, opt_state
  
  @jax.jit
  def step2(params, opt_state, n, nabla_n, nabla2_n, m, dy):
    x = jnp.tile(grids, (jnp.shape(n)[0], 1, 1))
    x = jnp.reshape(x, (-1, 3))
    n, nabla_n, nabla2_n = n.reshape(-1), nabla_n.reshape(-1, 3), nabla2_n.reshape(-1, 9)
    current_loss, gradients = jax.value_and_grad(get_loss_2)(params, x, n, nabla_n, nabla2_n, m, dy)
    updates, opt_state = optimizer.update(gradients, opt_state)
    params = optax.apply_updates(params, updates)
    return current_loss, params, opt_state
    
  for epoch in tqdm(range(FLAGS.epoch)):
    """if epoch < FLAGS.epoch // 2:
      for train_n, train_nabla_n, train_nabla2_n, train_m, train_dy, train_y in train_dataloader:
        current_loss, params, opt_state = step(params, opt_state, train_n, train_nabla_n, train_nabla2_n, train_m, train_dy)
    else:"""
    for train_n, train_nabla_n, train_nabla2_n, train_m, train_dy, train_y in train_dataloader:
      current_loss, params, opt_state = step2(params, opt_state, train_n, train_nabla_n, train_nabla2_n, train_m, train_dy)
    if epoch%1000==0:
      pred, pred_i, pred_f, pred_i_2 = [], [], [], []
      for test_n, test_nabla_n, test_nabla2_n, test_m, test_dy, test_y in test_dataloader:
        ret1, ret2, ret3, ret4 = test_loss(params, test_n, test_nabla_n, test_nabla2_n, test_m, test_y, test_dy)
        pred.append(ret1); pred_i.append(ret2); pred_f.append(ret3); pred_i_2.append(ret4)
      pred, pred_i, pred_f, i = jnp.concatenate(pred), jnp.concatenate(pred_i), jnp.concatenate(pred_f), jnp.concatenate(pred_i_2)
      test_m, test_y, test_dy = test_m.reshape(-1), test_y.reshape(-1), test_dy.reshape(-1)
      err_func = jnp.linalg.norm(jnp.reshape(pred - test_m, (-1,))) / jnp.linalg.norm(jnp.reshape(test_m, (-1,)))
      err_intor = jnp.linalg.norm(jnp.reshape(pred_i - test_y, (-1,))) / jnp.linalg.norm(jnp.reshape(test_y, (-1,)))
      err_intor_2 = jnp.linalg.norm(jnp.reshape(pred_i - i, (-1,))) / jnp.linalg.norm(jnp.reshape(i, (-1,)))
      err_FD = jnp.linalg.norm(jnp.reshape(pred_f - test_dy, (-1,))) / jnp.linalg.norm(jnp.reshape(test_dy, (-1,)))
      print('epoch %d, loss: %E, err_func: %E, err_intor: %E, error_intor_2: %E, err_FD: %E'%(epoch, current_loss, err_func, err_intor, err_intor_2, err_FD))

if __name__ == '__main__':
  app.run(main)
