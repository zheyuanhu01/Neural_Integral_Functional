import torch
from torch import nn
import torch.nn.functional as F
import numpy as np
from typing import Any, Sequence, Union
from tqdm import tqdm
from torch.utils.data import DataLoader, TensorDataset
import argparse

class SpectralConv1d(nn.Module):
    def __init__(self, in_channels, out_channels, modes1):
        super(SpectralConv1d, self).__init__()

        """
        1D Fourier layer. It does FFT, linear transform, and Inverse FFT.    
        """

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.modes1 = modes1  #Number of Fourier modes to multiply, at most floor(N/2) + 1

        self.scale = (1 / (in_channels*out_channels))
        self.weights1 = nn.Parameter(self.scale * torch.rand(in_channels, out_channels, self.modes1, dtype=torch.cfloat))

    # Complex multiplication
    def compl_mul1d(self, input, weights):
        # (batch, in_channel, x ), (in_channel, out_channel, x) -> (batch, out_channel, x)
        return torch.einsum("bix,iox->box", input, weights)

    def forward(self, x):
        batchsize = x.shape[0]
        #Compute Fourier coeffcients up to factor of e^(- something constant)
        x_ft = torch.fft.rfft(x)

        # Multiply relevant Fourier modes
        out_ft = torch.zeros(batchsize, self.out_channels, x.size(-1)//2 + 1,  device=x.device, dtype=torch.cfloat)
        out_ft[:, :, :self.modes1] = self.compl_mul1d(x_ft[:, :, :self.modes1], self.weights1)

        #Return to physical space
        x = torch.fft.irfft(out_ft, n=x.size(-1))
        return x

class FNO1d(nn.Module):
    def __init__(self, modes, width):
        super(FNO3d, self).__init__()

        """
        The overall network. It contains 4 layers of the Fourier layer.
        1. Lift the input to the desire channel dimension by self.fc0 .
        2. 4 layers of the integral operators u' = (W + K)(u).
            W defined by self.w; K defined by self.conv .
        3. Project from the channel space to the output space by self.fc1 and self.fc2 .
        
        input: the solution of the initial condition and location (a(x), x)
        input shape: (batchsize, x=s, c=2)
        output: the solution of a later timestep
        output shape: (batchsize, x=s, c=1)
        """

        self.modes1 = modes
        self.width = width
        self.padding = 2 # pad the domain if input is non-periodic
        self.fc0 = nn.Linear(7, self.width) # input channel is 2: (a(x), x)

        self.conv0 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv1 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv2 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv3 = SpectralConv1d(self.width, self.width, self.modes1)
        self.w0 = nn.Conv1d(self.width, self.width, 1)
        self.w1 = nn.Conv1d(self.width, self.width, 1)
        self.w2 = nn.Conv1d(self.width, self.width, 1)
        self.w3 = nn.Conv1d(self.width, self.width, 1)

        self.fc1 = nn.Linear(self.width, 128)
        self.fc2 = nn.Linear(128, 1)
        #self.fc3 = nn.Linear(100, 1)

    def forward(self, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3):
        x = torch.cat((x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3), dim=-1)
        x = self.fc0(x)
        x = x.permute(0, 2, 1)

        x1 = self.conv0(x)
        x2 = self.w0(x)
        x = x1 + x2
        x = F.gelu(x)

        x1 = self.conv1(x)
        x2 = self.w1(x)
        x = x1 + x2
        x = F.gelu(x)

        x1 = self.conv2(x)
        x2 = self.w2(x)
        x = x1 + x2
        x = F.gelu(x)

        x1 = self.conv3(x)
        x2 = self.w3(x)
        x = x1 + x2

        # x = x[..., :-self.padding] # pad the domain if input is non-periodic
        x = x.permute(0, 2, 1)
        x = self.fc1(x)
        x = F.gelu(x)
        x = self.fc2(x)
        #x = x.squeeze()
        #x = self.fc3(x)
        #x = x.mean(-2)
        return x
    
    def get_grid(self, shape, device):
        batchsize, size_x = shape[0], shape[1]
        gridx = torch.tensor(np.linspace(0, 1, size_x), dtype=torch.float)
        gridx = gridx.reshape(1, size_x, 1).repeat([batchsize, 1, 1])
        return gridx.to(device)
    
    def FD(self, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3, nabla2_n):
        out = self.forward(x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3) # [batch, N_grid, 1]
        y_n = torch.autograd.grad(out, n, create_graph=True, grad_outputs=torch.ones_like(out))[0] # [batch, N_grid, 1]
        """y_nabla_n1 = torch.autograd.grad(out.sum(), nabla_n1, create_graph=True)[0] # [batch, N_grid, 1]
        y_nabla_n2 = torch.autograd.grad(out.sum(), nabla_n2, create_graph=True)[0] # [batch, N_grid, 1]
        y_nabla_n3 = torch.autograd.grad(out.sum(), nabla_n3, create_graph=True)[0] # [batch, N_grid, 1]
        temp11 = torch.autograd.grad(y_nabla_n1.sum(), x1, create_graph=True)[0] # [batch, N_grid, 1]
        temp12 = torch.autograd.grad(y_nabla_n2.sum(), x2, create_graph=True)[0] # [batch, N_grid, 1]
        temp13 = torch.autograd.grad(y_nabla_n3.sum(), x3, create_graph=True)[0] # [batch, N_grid, 1]
        temp1 = temp11 + temp12 + temp13
        temp21 = torch.autograd.grad(y_nabla_n1.sum(), n, create_graph=True)[0] # [batch, N_grid, 1]
        temp22 = torch.autograd.grad(y_nabla_n2.sum(), n, create_graph=True)[0] # [batch, N_grid, 1]
        temp23 = torch.autograd.grad(y_nabla_n3.sum(), n, create_graph=True)[0] # [batch, N_grid, 1]
        temp2 = temp21 * nabla_n1 + temp22 * nabla_n2 + temp23 * nabla_n3
        temp31 = torch.autograd.grad(y_nabla_n1.sum(), nabla_n1, create_graph=True)[0] # [batch, N_grid, 1]
        temp32 = torch.autograd.grad(y_nabla_n1.sum(), nabla_n2, create_graph=True)[0] # [batch, N_grid, 1]
        temp33 = torch.autograd.grad(y_nabla_n1.sum(), nabla_n3, create_graph=True)[0] # [batch, N_grid, 1]
        temp34 = torch.autograd.grad(y_nabla_n2.sum(), nabla_n1, create_graph=True)[0] # [batch, N_grid, 1]
        temp35 = torch.autograd.grad(y_nabla_n2.sum(), nabla_n2, create_graph=True)[0] # [batch, N_grid, 1]
        temp36 = torch.autograd.grad(y_nabla_n2.sum(), nabla_n3, create_graph=True)[0] # [batch, N_grid, 1]
        temp37 = torch.autograd.grad(y_nabla_n3.sum(), nabla_n1, create_graph=True)[0] # [batch, N_grid, 1]
        temp38 = torch.autograd.grad(y_nabla_n3.sum(), nabla_n2, create_graph=True)[0] # [batch, N_grid, 1]
        temp39 = torch.autograd.grad(y_nabla_n3.sum(), nabla_n3, create_graph=True)[0] # [batch, N_grid, 1]
        temp3 = temp31 * nabla2_n[:, :, 0:1] + temp32 + temp33 + temp34 + temp35 + temp36 + temp37 + temp38 + temp39"""
        return y_n# - temp1 - temp2 - temp3
    
    """def FD(self, x, n, nabla_n, nabla2_n):
        out = self.forward(x, n, nabla_n) # [batch, 1]
        y_n = torch.autograd.grad(out.sum(), n, create_graph=True)[0] # [batch, N_grid, 1]
        y_nabla_n = torch.autograd.grad(out.sum(), nabla_n, create_graph=True)[0] # [batch, N_grid, 3]
        temp11 = torch.autograd.grad(y_nabla_n[:, :, 0].sum(), x[:, :, 0:1], create_graph=True)[0] # [batch, N_grid, 1]
        temp12 = torch.autograd.grad(y_nabla_n[:, :, 1].sum(), x[:, :, 1:2], create_graph=True)[0] # [batch, N_grid, 1]
        temp13 = torch.autograd.grad(y_nabla_n[:, :, 2].sum(), x[:, :, 2:3], create_graph=True)[0] # [batch, N_grid, 1]
        temp1 = temp11 + temp12 + temp13
        temp2 = torch.autograd.grad(y_nabla_n.sum(0).sum(0), n, create_graph=True)[0] # [batch, N_grid, 3, 1]
        temp2 = temp2[:, :, 0] * nabla_n[:, :, 0] + temp2[:, :, 1] * nabla_n[:, :, 1] + temp2[:, :, 2] * nabla_n[:, :, 2]
        temp3 = torch.autograd.grad(y_nabla_n.sum(0).sum(0), nabla_n, create_graph=True)[0] # [batch, N_grid, 3, 3]
        temp3 *= nabla2_n
        temp3 = temp3.sum(-1).sum(-1)
        return y_n - temp1 - temp2 - temp3"""

class FNO1d(nn.Module):
    def __init__(self, modes, width):
        super(FNO3d, self).__init__()

        """
        The overall network. It contains 4 layers of the Fourier layer.
        1. Lift the input to the desire channel dimension by self.fc0 .
        2. 4 layers of the integral operators u' = (W + K)(u).
            W defined by self.w; K defined by self.conv .
        3. Project from the channel space to the output space by self.fc1 and self.fc2 .
        
        input: the solution of the initial condition and location (a(x), x)
        input shape: (batchsize, x=s, c=2)
        output: the solution of a later timestep
        output shape: (batchsize, x=s, c=1)
        """

        self.modes1 = modes
        self.width = width
        self.padding = 2 # pad the domain if input is non-periodic
        self.fc0 = nn.Linear(7, self.width) # input channel is 2: (a(x), x)

        self.conv0 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv1 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv2 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv3 = SpectralConv1d(self.width, self.width, self.modes1)
        self.w0 = nn.Conv1d(self.width, self.width, 1)
        self.w1 = nn.Conv1d(self.width, self.width, 1)
        self.w2 = nn.Conv1d(self.width, self.width, 1)
        self.w3 = nn.Conv1d(self.width, self.width, 1)

        self.fc1 = nn.Linear(self.width, 128)
        self.fc2 = nn.Linear(128, 1)
        #self.fc3 = nn.Linear(100, 1)

    def forward(self, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3):
        x = torch.cat((x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3), dim=-1)
        x = self.fc0(x)
        x = x.permute(0, 2, 1)

        x1 = self.conv0(x)
        x2 = self.w0(x)
        x = x1 + x2
        x = F.gelu(x)

        x1 = self.conv1(x)
        x2 = self.w1(x)
        x = x1 + x2
        x = F.gelu(x)

        x1 = self.conv2(x)
        x2 = self.w2(x)
        x = x1 + x2
        x = F.gelu(x)

        x1 = self.conv3(x)
        x2 = self.w3(x)
        x = x1 + x2

        # x = x[..., :-self.padding] # pad the domain if input is non-periodic
        x = x.permute(0, 2, 1)
        x = self.fc1(x)
        x = F.gelu(x)
        x = self.fc2(x)
        return x
    
    def get_grid(self, shape, device):
        batchsize, size_x = shape[0], shape[1]
        gridx = torch.tensor(np.linspace(0, 1, size_x), dtype=torch.float)
        gridx = gridx.reshape(1, size_x, 1).repeat([batchsize, 1, 1])
        return gridx.to(device)
    
    def FD(self, x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3, nabla2_n):
        out = self.forward(x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3) # [batch, N_grid, 1]
        y_n = torch.autograd.grad(out, n, create_graph=True, grad_outputs=torch.ones_like(out))[0] # [batch, N_grid, 1]
        return y_n# - temp1 - temp2 - temp3



class FunctionalDataset(TensorDataset):
    def __init__(self, n, nabla_n, nabla2_n, y, dy):
        self.n = n
        self.nabla_n = nabla_n
        self.nabla2_n = nabla2_n
        self.y = y
        self.dy = dy

    def __len__(self):
        return len(self.n)

    def __getitem__(self, idx):
        return self.n[idx], self.nabla_n[idx], self.nabla2_n[idx], self.y[idx], self.dy[idx]

class FunctionalDataset3D(TensorDataset):
    def __init__(self, n, nabla_n, nabla2_n, y, dy, e):
        self.n = n
        self.nabla_n = nabla_n
        self.nabla2_n = nabla2_n
        self.y = y
        self.dy = dy
        self.e = e

    def __len__(self):
        return len(self.n)

    def __getitem__(self, idx):
        return self.n[idx], self.nabla_n[idx], self.nabla2_n[idx], self.y[idx], self.dy[idx], self.e[idx]  

if __name__ == "__main__":
    model = FNO1d(16, 64)
    x, n, nabla_n, nabla2_n = torch.randn(2, 100, 3), torch.randn(2, 100, 1), torch.randn(2, 100, 3), torch.randn(2, 100, 9)
    x1, x2, x3, nabla_n1, nabla_n2, nabla_n3 = x[:, :, 0:1], x[:, :, 1:2], x[:, :, 2:3], nabla_n[:, :, 0:1], nabla_n[:, :, 1:2], nabla_n[:, :, 2:3]
    y = model(x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3)
    print(y.shape)

    x1, x2, x2, n = x1.requires_grad_(), x2.requires_grad_(), x3.requires_grad_(), n.requires_grad_()
    nabla_n1, nabla_n2, nabla_n3 = nabla_n1.requires_grad_(), nabla_n2.requires_grad_(), nabla_n3.requires_grad_()
    dy = model.FD(x1, x2, x3, n, nabla_n1, nabla_n2, nabla_n3, nabla2_n)
    print(dy.shape)
    pass