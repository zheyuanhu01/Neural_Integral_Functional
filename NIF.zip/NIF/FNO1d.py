import haiku as hk
import jax
import numpy as np
import jax.numpy as jnp
from typing import Any, Sequence, Union
import optax
from tqdm import tqdm
import matplotlib.pyplot as plt
import argparse

class ComplexRandomUniform(hk.initializers.Initializer):
    """Initializes by sampling from a uniform distribution."""

    def __init__(self, minval=0., maxval=1.):
        """Constructs a :class:`RandomUniform` initializer.
        Args:
            minval: The lower limit of the uniform distribution.
            maxval: The upper limit of the uniform distribution.
        """
        self.minval = minval
        self.maxval = maxval

    def __call__(self, shape: Sequence[int], dtype: Any) -> jnp.ndarray:
        return jax.random.uniform(hk.next_rng_key(), shape, dtype, self.minval, self.maxval) + 0.j

class SpectralConv1d(hk.Module):
    def __init__(self, in_channels, out_channels, modes1):
        super(SpectralConv1d, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.modes1 = modes1 # Number of Fourier modes to multiply, at most floor(N/2) + 1
        self.scale = (1 / (in_channels * out_channels))

    def __call__(self, x):
        batchsize = jnp.shape(x)[0]
        x_ft = jnp.fft.rfft(x)
        w_init = hk.initializers.RandomUniform(maxval=self.scale) #ComplexRandomUniform(maxval=self.scale)
        weights1 = hk.get_parameter("weights1", shape=[self.in_channels, self.out_channels, self.modes1], dtype=x.dtype, init=w_init)
        weights2 = hk.get_parameter("weights2", shape=[self.in_channels, self.out_channels, self.modes1], dtype=x.dtype, init=w_init)
        out_ft = jnp.zeros((batchsize, self.out_channels, jnp.shape(x)[-1] // 2 + 1), dtype=x_ft.dtype)
        out_ft.at[:, :, :self.modes1].set(jnp.einsum("bix,iox->box", x_ft[:, :, :self.modes1], weights1))
        out_ft.at[:, :, :self.modes1].add(jnp.einsum("bix,iox->box", x_ft[:, :, :self.modes1], weights2 * 1.j))
        x = jnp.fft.irfft(out_ft, n=jnp.shape(x)[-1])
        return x

class FNO1d(hk.Module):
    def __init__(self, modes, width):
        super(FNO1d, self).__init__()
        self.modes1 = modes
        self.width = width
        self.padding = 2 # pad the domain if input is non-periodic
        self.fc0 = hk.Linear(self.width) # input channel is 2: (a(x), x)

        self.conv0 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv1 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv2 = SpectralConv1d(self.width, self.width, self.modes1)
        self.conv3 = SpectralConv1d(self.width, self.width, self.modes1)
        self.w0 = hk.Conv1D(self.width, 1, data_format='NCW')
        self.w1 = hk.Conv1D(self.width, 1, data_format='NCW')
        self.w2 = hk.Conv1D(self.width, 1, data_format='NCW')
        self.w3 = hk.Conv1D(self.width, 1, data_format='NCW')

        self.fc1 = hk.Linear(128)
        self.fc2 = hk.Linear(1)

    def __call__(self, x, n, nabla_n):
        x = jnp.concatenate([x, n, nabla_n], axis=-1)
        x = jnp.expand_dims(x, 0)
        #grid = self.get_grid(jnp.shape(x))
        #x = jnp.concatenate([x, grid], axis=-1)
        x = self.fc0(x)
        x = jnp.transpose(x, (0, 2, 1))

        x1 = self.conv0(x)
        x2 = self.w0(x)
        x = x1 + x2
        x = jax.nn.gelu(x)

        x1 = self.conv1(x)
        x2 = self.w1(x)
        x = x1 + x2
        x = jax.nn.gelu(x)

        x1 = self.conv2(x)
        x2 = self.w2(x)
        x = x1 + x2
        x = jax.nn.gelu(x)

        x1 = self.conv3(x)
        x2 = self.w3(x)
        x = x1 + x2

        # x = x[..., :-self.padding] # pad the domain if input is non-periodic
        x = jnp.transpose(x, (0, 2, 1))
        x = self.fc1(x)
        x = jax.nn.gelu(x)
        x = self.fc2(x)
        x = jnp.squeeze(x)
        x = jnp.mean(x, -1)
        return x

    def get_grid(self, shape):
        batchsize, size_x = shape[0], shape[1]
        gridx = jnp.linspace(0, 1, size_x)
        gridx = jnp.reshape(gridx, (1, size_x, 1))
        gridx = jnp.repeat(gridx, batchsize, axis=0)
        #gridx = gridx.reshape(1, size_x, 1).repeat([batchsize, 1, 1])
        return gridx

def get_grid(shape):
    batchsize, size_x = shape[0], shape[1]
    gridx = jnp.linspace(0, 1, size_x)
    gridx = jnp.reshape(gridx, (1, size_x, 1))
    gridx = jnp.repeat(gridx, batchsize, axis=0)
    #gridx = gridx.reshape(1, size_x, 1).repeat([batchsize, 1, 1])
    return gridx

def polynomial(B=1100, N=20):
    a = (np.random.rand(B, N) - 0.5) * 2
    def poly(x):
        return (a @ (np.reshape(x, (-1, 1)) ** np.arange(N)).T)
    def nabla_poly(x):
        return (a[:, 1:] @ (np.arange(1, N).reshape(-1, 1) * (np.reshape(x, (-1, 1)) ** np.arange(N-1)).T))
    def nabla2_poly(x):
        return (a[:, 2:] @ (np.arange(2, N).reshape(-1, 1) * np.arange(1, N-1).reshape(-1, 1) * \
            (np.reshape(x, (-1, 1)) ** np.arange(N-2)).T))
    def integrate():
        return (a @ np.reshape(1. / np.arange(1, N+1), (-1, 1)))
    x = np.linspace(0, 1, 100)
    n, nabla_n, nabla2_n = poly(x), nabla_poly(x), nabla2_poly(x)
    n, nabla_n, nabla2_n = np.expand_dims(n, axis=-1), np.expand_dims(nabla_n, axis=-1), np.expand_dims(nabla2_n, axis=-1)
    y = integrate()
    print(np.mean(y), np.std(y))
    #y = poly(x)
    #i1 = jnp.mean(y, axis=-1)
    #print(i1, integrate())
    dy = np.ones_like(n)
    train_n, train_nabla_n, train_y, test_n, test_nabla_n, test_y = n[:int(0.9 * B), :, :], nabla_n[:int(0.9 * B), :, :], \
        y[:int(0.9 * B)], n[int(0.9 * B):, :, :], nabla_n[int(0.9 * B):, :, :], y[int(0.9 * B):]
    train_dy, test_dy = dy[:int(0.9 * B)], dy[int(0.9 * B):]
    train_nabla2_n, test_nabla2_n = nabla2_n[:int(0.9 * B)], nabla2_n[int(0.9 * B):]
    return train_n, train_nabla_n, train_nabla2_n, train_y, train_dy, test_n, test_nabla_n, test_nabla2_n, test_y, test_dy


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Neural Functional Project')
    parser.add_argument('--N_data', type=int, default=1100)
    parser.add_argument('--dataset', type=str, default="sin")
    parser.add_argument('--batch_size', type=int, default=1000)
    parser.add_argument('--epochs', type=int, default=10001)
    parser.add_argument('--lam_f', type=float, default=0)
    parser.add_argument('--order', type=int, default=0)
    args = parser.parse_args()
    key = jax.random.PRNGKey(0)
    train_n, train_nabla_n, train_nabla2_n, train_y, train_dy, test_n, test_nabla_n, test_nabla2_n, test_y, test_dy = polynomial(B=args.N_data)
    @hk.transform
    def network(x, n, nabla_n):
        temp = FNO1d(20, 64) 
        return temp(x, n, nabla_n)
        
    net = hk.without_apply_rng(network)
    train_x, test_x = get_grid(jnp.shape(train_n)), get_grid(jnp.shape(test_n))
    params = net.init(key, train_x[0], train_n[0], train_nabla_n[0])
    net_pred_fn = net.apply
    net_pred_fn = jax.vmap(net.apply, (None, 0, 0, 0))
    fd_pred_fn = jax.vmap(jax.grad(net.apply, argnums=1), (None, 0, 0, 0))

    optimizer = optax.adam(1e-3)
    opt_state = optimizer.init(params)

    @jax.jit
    def get_loss(params):
        y_pred = net_pred_fn(params, train_x, train_n, train_nabla_n)
        loss1 = jnp.mean((y_pred - train_y)**2)
        if args.lam_f > 0:
            f_pred = fd_pred_fn(params, train_x) * 100
            loss2 = jnp.mean((f_pred - train_dy)**2)
        else:
            loss2 = 0
        loss1 += loss2
        return loss1, (loss1, loss2)

    @jax.jit
    def test_loss(params):
        y_pred = net_pred_fn(params, test_x, test_n, test_nabla_n)
        #f_pred = fd_pred_fn(params, test_x) * 100
        #loss1, loss2 = jnp.linalg.norm(y_pred - test_y) / jnp.linalg.norm(test_y), jnp.linalg.norm(f_pred - test_dy) / jnp.linalg.norm(test_dy)
        #return loss1, loss2
        loss1, loss2 = jnp.linalg.norm(y_pred - test_y) / jnp.linalg.norm(test_y), 0
        return loss1, loss2

    @jax.jit
    def step(params, opt_state):
        (current_loss, losses), gradients = jax.value_and_grad(get_loss, has_aux=True)(params)
        updates, opt_state = optimizer.update(gradients, opt_state)
        params = optax.apply_updates(params, updates)
        y_loss, f_loss = losses
        return current_loss, params, opt_state, y_loss, f_loss
        
    for n in tqdm(range(int(1e4))):
        current_loss, params, opt_state, y_loss, f_loss = step(params, opt_state)
        if n%1000==0:
            te_loss = test_loss(params)
            print('epoch %d, y loss: %g, f loss: %f, test y: %g, test f: %g'%(n, y_loss, f_loss, te_loss[0], te_loss[1]))
    
    print(params)