import jax
import jax.numpy as jnp

rho = lambda r: jnp.exp(-jnp.sum(r**2))


def integrand_gga_x_pbe(rho, nabla_rho):
    """GGA_X_PBE
  """
    kappa = 0.8040

    # mu value is taken from libxc
    # mu = 0.2195149727645171

    # kappa = 0.967
    # mu = 0.235
    mu = 0.06672455060314922 * (jnp.pi**2) / 3

    def phi_x(s):
        """
        Eq. (14) in PBE paper.
        """
        return jnp.where(s < 1e-20, 1,
                         1 + kappa - kappa / (1 + mu * s * s / kappa))

    def n2s(n, nabla_n):
        # k_F = (3 * jnp.pi**2 * n + 1e-20)**(1 / 3)

        # denom = 2 * k_F * n + 1e-20

        # variant
        denom_ = 2 * (3 * jnp.pi**2)**(1 / 3) * (n)**(4 / 3)

        denom = jnp.where(denom_ < 1e-20, 1e-20, denom_)
        # s = |\nabla n| / 2 * k_F * n
        s = jnp.sqrt(jnp.sum(nabla_n**2) + 1e-40) / denom
        return s

    def epsilon_X_unif(n):
        """
        Eq. (10) in PBE paper.
        """
        k_F = (3 * jnp.pi**2 * n + 1e-20)**(1 / 3)
        return -3 * k_F / (4 * jnp.pi)

    def v(n, nabla_n):
        s = n2s(n, nabla_n)
        return epsilon_X_unif(n) * n * phi_x(s)

    return jax.lax.cond(rho < 1e-10,
                        lambda _: 0.,
                        lambda _: v(rho, nabla_rho),
                        operand=None)


def integrand_x_gga(rho, nabla_rho):
    m = 1. / 15
    const = -3 / 4 * (3 / jnp.pi)**(1 / 3)
    #k_F = (3 * jnp.pi**2 * rho)**(1. / 3)
    k_F = jnp.cbrt(3 * jnp.pi**2)
    s2 = jnp.sum(nabla_rho**2, axis=-1) / (2 * k_F)**2  # /（rho）**(8/3)
    return const * rho**(
        4 / 3 - 8 / 15) * (rho**8 + 0.0864 * s2**1 * rho**(16 / 3) / m +
                           14 * s2**2 * rho**(8 / 3) + 0.2 * s2**3)**m


def screen(rho, nabla_rho):
    return


x = jax.random.uniform(jax.random.PRNGKey(0), (1000, 3), minval=-10, maxval=10)
rhos = jax.vmap(rho)(x)
nabla_rhos = jax.vmap(jax.grad(rho))(x)
res = jax.vmap(integrand_x_gga)(rhos, nabla_rhos)
print(jnp.isnan(res).any())

partial_one = jax.grad(integrand_x_gga, argnums=0)
partial_two = jax.grad(integrand_x_gga, argnums=1)
partial_one_res = jax.vmap(partial_one)(rhos, nabla_rhos)
partial_two_res = jax.vmap(partial_two)(rhos, nabla_rhos)
print(jnp.isnan(partial_one_res).any())
print(jnp.isnan(partial_two_res).any())

# # find the index of nan
# nan_idx = jnp.where(jnp.isnan(partial_one_res))
# # take the first nan index
# nan_idx = nan_idx[0][0]
# # print the input of rhos and nabla_rhos
# print(rhos[nan_idx])
# print(nabla_rhos[nan_idx])

partial_one = jax.grad(screen, argnums=0)
partial_two = jax.grad(screen, argnums=1)
partial_one_res = jax.vmap(partial_one)(rhos, nabla_rhos)
partial_two_res = jax.vmap(partial_two)(rhos, nabla_rhos)
print(jnp.isnan(partial_one_res).any())
print(jnp.isnan(partial_two_res).any())

# find the index of nan
# nan_idx = jnp.where(jnp.isnan(partial_one_res))
# # take the first nan index
# nan_idx = nan_idx[0][0]
# # print the input of rhos and nabla_rhos
# print(rhos[nan_idx])
# print(nabla_rhos[nan_idx])

partial_one = jax.grad(integrand_gga_x_pbe, argnums=0)
partial_two = jax.grad(integrand_gga_x_pbe, argnums=1)
partial_one_res = jax.vmap(partial_one)(rhos, nabla_rhos)
partial_two_res = jax.vmap(partial_two)(rhos, nabla_rhos)
print(jnp.isnan(partial_one_res).any())
print(jnp.isnan(partial_two_res).any())
